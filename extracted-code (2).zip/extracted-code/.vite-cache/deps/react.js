import { t as require_react } from "./react-DTmY7kNl.js";
export default require_react();
