/* eslint-disable react-refresh/only-export-components */
import { createContext, useContext, useEffect, useState } from 'react';
import {
  auditTrailSeed,
  createCategoriesFromUpload,
  createDemoBid,
  createTenderFromUpload,
  demoTenders,
  evaluationCategories,
  getAllBids,
} from '../data/procurementData';

const STORAGE_KEY = 'evalpro-hackathon-state-v1';
const ProcurementContext = createContext(null);

function clone(value) {
  return JSON.parse(JSON.stringify(value));
}

function applyEvaluationToTender(tender) {
  tender.status = 'Evaluation Complete';
  tender.bids = tender.bids.map((bid) => ({
    ...bid,
    status: bid.status === 'Pending' ? 'Evaluated' : bid.status,
    score: Math.min(bid.score + 4, 98),
  }));
}

function createInitialState() {
  return {
    tenders: clone(demoTenders),
    categories: clone(evaluationCategories),
    auditLogs: clone(auditTrailSeed),
    selectedTenderId: demoTenders[0].id,
    lastUploadedFile: null,
  };
}

function loadState() {
  try {
    const stored = window.localStorage.getItem(STORAGE_KEY);
    return stored ? JSON.parse(stored) : createInitialState();
  } catch {
    return createInitialState();
  }
}

function makeAuditLog(actionType, description, meta = {}) {
  const stamp = Date.now();
  return {
    id: `LOG-${stamp}`,
    timestamp: new Date().toISOString(),
    actor: meta.actor || 'Procurement Officer',
    actionType,
    description,
    tenderId: meta.tenderId,
    bidId: meta.bidId,
    hash: `0x${Math.abs(description.split('').reduce((sum, char) => sum + char.charCodeAt(0), stamp)).toString(16).slice(0, 8)}`,
  };
}

export function ProcurementProvider({ children }) {
  const [state, setState] = useState(loadState);

  useEffect(() => {
    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    } catch {
      // Some browsers restrict storage for double-clicked local HTML files.
    }
  }, [state]);

  const addAudit = (draft, actionType, description, meta) => {
    draft.auditLogs = [makeAuditLog(actionType, description, meta), ...draft.auditLogs];
  };

  const selectTender = (tenderId) => {
    setState((previous) => ({ ...previous, selectedTenderId: tenderId }));
  };

  const resetDemo = () => {
    setState(createInitialState());
  };

  const lockCriteria = (tenderId) => {
    setState((previous) => {
      const draft = clone(previous);
      const tender = draft.tenders.find((item) => item.id === tenderId);
      if (tender) {
        tender.criteriaLocked = true;
        tender.status = 'Criteria Locked';
        addAudit(draft, 'Criteria', `Locked criteria for ${tender.title}.`, { tenderId });
      }
      return draft;
    });
  };

  const updateCriterionStatus = (categoryId, subcategoryId, status) => {
    setState((previous) => {
      const draft = clone(previous);
      const category = draft.categories.find((item) => item.id === categoryId);
      const subcategory = category?.subcategories.find((item) => item.id === subcategoryId);
      if (subcategory) {
        subcategory.status = status;
        addAudit(draft, 'Criteria', `Marked ${subcategory.name} as ${status}.`, {
          tenderId: draft.selectedTenderId,
        });
      }
      return draft;
    });
  };

  const updateCriterionThreshold = (categoryId, subcategoryId, threshold) => {
    setState((previous) => {
      const draft = clone(previous);
      const category = draft.categories.find((item) => item.id === categoryId);
      const subcategory = category?.subcategories.find((item) => item.id === subcategoryId);
      if (subcategory) {
        subcategory.threshold = threshold;
        addAudit(draft, 'Criteria', `Updated threshold for ${subcategory.name}.`, {
          tenderId: draft.selectedTenderId,
        });
      }
      return draft;
    });
  };

  const addUploadedTender = (fileName, options = {}) => {
    setState((previous) => {
      const draft = clone(previous);
      const uploadedTender = createTenderFromUpload(fileName);

      if (uploadedTender) {
        const existingIndex = draft.tenders.findIndex((item) => item.id === uploadedTender.id);
        if (existingIndex >= 0) {
          draft.tenders[existingIndex] = uploadedTender;
        } else {
          draft.tenders = [uploadedTender, ...draft.tenders];
        }

        draft.categories = createCategoriesFromUpload(fileName);
        draft.selectedTenderId = uploadedTender.id;
        draft.lastUploadedFile = fileName;

        if (options.autoEvaluate) {
          applyEvaluationToTender(uploadedTender);
        }

        const extractedCategoryCount = draft.categories.length;
        const extractedRuleCount = draft.categories.reduce((total, category) => total + category.subcategories.length, 0);

        addAudit(draft, 'Upload', `Uploaded and parsed ${fileName}.`, {
          tenderId: uploadedTender.id,
          actor: 'System',
        });
        addAudit(
          draft,
          'Criteria',
          `Extracted ${extractedCategoryCount} evaluation categories and ${extractedRuleCount} tender rules from ${fileName}.`,
          {
            tenderId: uploadedTender.id,
            actor: 'GPT Engine',
          },
        );
        addAudit(
          draft,
          'Submission',
          `Created ${uploadedTender.bids.length} bid submissions for ${uploadedTender.title}.`,
          {
            tenderId: uploadedTender.id,
            actor: 'System',
          },
        );
        if (options.autoEvaluate) {
          addAudit(
            draft,
            'Evaluation',
            `Auto-ran bid evaluation for ${uploadedTender.bids.length} submissions from ${uploadedTender.title}.`,
            {
              tenderId: uploadedTender.id,
              actor: 'GPT Engine',
            },
          );
        }

        return draft;
      }

      draft.lastUploadedFile = fileName;
      addAudit(draft, 'Upload', `Uploaded and parsed ${fileName}.`, {
        tenderId: draft.selectedTenderId,
        actor: 'System',
      });
      return draft;
    });
  };

  const addDemoBidToTender = (tenderId) => {
    setState((previous) => {
      const draft = clone(previous);
      const tender = draft.tenders.find((item) => item.id === tenderId);
      if (tender) {
        const bid = createDemoBid(tender, tender.bids.length);
        tender.bids.push(bid);
        addAudit(draft, 'Submission', `Added ${bid.bidderName} to ${tender.title}.`, {
          tenderId,
          bidId: bid.id,
        });
      }
      return draft;
    });
  };

  const runEvaluation = (tenderId) => {
    setState((previous) => {
      const draft = clone(previous);
      const tender = draft.tenders.find((item) => item.id === tenderId);
      if (tender) {
        applyEvaluationToTender(tender);
        addAudit(draft, 'Evaluation', `Ran GPT-style evaluation for ${tender.bids.length} bids in ${tender.title}.`, {
          tenderId,
          actor: 'GPT Engine',
        });
      }
      return draft;
    });
  };

  const updateBidDecision = (bidId, decision, reason = '') => {
    setState((previous) => {
      const draft = clone(previous);
      for (const tender of draft.tenders) {
        const bid = tender.bids.find((item) => item.id === bidId);
        if (bid) {
          const cleanedReason = reason.trim();
          bid.decision = decision;
          bid.status = decision === 'Clarification Requested' ? 'Needs Review' : 'Evaluated';
          bid.decisionReason = decision === 'Rejected' ? cleanedReason : '';
          const description = decision === 'Rejected' && cleanedReason
            ? `Rejected ${bid.bidderName}. Reason: ${cleanedReason}`
            : `${decision} for ${bid.bidderName}.`;
          addAudit(draft, 'Decision', description, {
            tenderId: tender.id,
            bidId: bid.id,
          });
          break;
        }
      }
      return draft;
    });
  };

  const allBids = getAllBids(state.tenders);
  const selectedTender = state.tenders.find((item) => item.id === state.selectedTenderId) || state.tenders[0];
  const value = {
    ...state,
    allBids,
    selectedTender,
    addDemoBidToTender,
    addUploadedTender,
    lockCriteria,
    resetDemo,
    runEvaluation,
    selectTender,
    updateBidDecision,
    updateCriterionThreshold,
    updateCriterionStatus,
    getBidById: (bidId) => allBids.find((item) => item.id === bidId),
    getTenderById: (tenderId) => state.tenders.find((item) => item.id === tenderId),
  };

  return <ProcurementContext.Provider value={value}>{children}</ProcurementContext.Provider>;
}

export function useProcurement() {
  const context = useContext(ProcurementContext);
  if (!context) {
    throw new Error('useProcurement must be used inside ProcurementProvider');
  }
  return context;
}
