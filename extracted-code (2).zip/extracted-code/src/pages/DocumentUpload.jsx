import { useRef, useState } from 'react';
import { ArrowRight, CheckCircle, Cpu, Download, File, FileUp, UploadCloud } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useProcurement } from '../context/ProcurementContext';
import { featuredSampleTender, getSampleTenderByFileName } from '../data/procurementData';

export default function DocumentUpload() {
  const [status, setStatus] = useState('idle');
  const [fileName, setFileName] = useState('');
  const [uploadedTenderId, setUploadedTenderId] = useState(null);
  const [matchedSample, setMatchedSample] = useState(null);
  const fileInputRef = useRef(null);
  const { addUploadedTender, categories, runEvaluation, selectedTender, tenders } = useProcurement();
  const navigate = useNavigate();
  const matchedTender = tenders.find((tender) => tender.id === uploadedTenderId) || null;
  const previewTender = matchedTender || (status === 'done' && matchedSample ? selectedTender : null);
  const totalSubcategories = categories.reduce((total, category) => total + category.subcategories.length, 0);
  const fallbackDocuments = matchedSample?.previewDocuments || featuredSampleTender.previewDocuments;
  const fallbackHighlights = matchedSample?.criteriaHighlights || (
    status === 'done'
      ? [
          {
            id: 'generic-upload',
            title: 'Prototype extraction ready',
            clause: 'System',
            detail: `${fileName} has been indexed for review in the prototype workflow.`,
          },
        ]
      : featuredSampleTender.criteriaHighlights
  );
  const previewDocuments = previewTender?.extractionSummary?.previewDocuments
    || previewTender?.bids?.flatMap((bid) => bid.documents).slice(0, 6).map((doc) => doc.name)
    || fallbackDocuments;
  const previewHighlights = previewTender?.extractionSummary?.criteriaHighlights
    || fallbackHighlights;
  const highestPriorityScore = previewTender?.bids?.reduce(
    (highest, bid) => Math.max(highest, bid.priorityScore),
    0,
  ) || 0;

  const chooseFile = (name) => {
    const sample = getSampleTenderByFileName(name);
    setFileName(name);
    setMatchedSample(sample);
    setUploadedTenderId(sample?.tenderId || null);
    setStatus('selected');
  };

  const handleFileSelect = (event) => {
    const file = event.target.files?.[0];
    if (file) {
      chooseFile(file.name);
    }
  };

  const processFile = () => {
    if (!fileName) return;
    setStatus('uploading');
    window.setTimeout(() => {
      setStatus('processing');
      window.setTimeout(() => {
        if (matchedSample?.tenderId) {
          addUploadedTender(fileName, { autoEvaluate: true });
          setStatus('routing');
          window.setTimeout(() => {
            navigate('/priority');
          }, 1000);
          return;
        }

        addUploadedTender(fileName);
        setStatus('done');
      }, 950);
    }, 700);
  };

  const openCriteria = () => navigate('/criteria');
  const openBidSubmissions = () => navigate('/bids');
  const sendToEvaluation = () => {
    if (previewTender?.id) {
      runEvaluation(previewTender.id);
    }
    navigate('/priority');
  };

  return (
    <div className="upload-page">
      <section className="panel upload-card">
        <div className={`upload-icon ${status}`}>
          {status === 'done' || status === 'routing' ? <CheckCircle size={46} /> : <FileUp size={46} />}
        </div>

        <span className="eyebrow">Tender ingestion</span>
        <h2>Upload Tender Package</h2>
        <p>Choose a tender PDF and the demo engine will extract category and subcategory criteria.</p>

        <div className="sample-download-panel">
          <div className="sample-tender-card">
            <span className="mini-label">Featured sample tender</span>
            <strong>{featuredSampleTender.title}</strong>
            <p>{featuredSampleTender.subtitle}</p>
            <div className="sample-tender-meta">
              <span>{featuredSampleTender.tenderTemplate.gemId}</span>
              <span>{featuredSampleTender.tenderTemplate.budget}</span>
              <span>Due {featuredSampleTender.tenderTemplate.deadline}</span>
            </div>
          </div>
          <p className="upload-helper">
            Download the sample tender PDF, then upload that same file here to drive the full demo workflow.
          </p>
          <a
            className="btn btn-outline sample-download-btn"
            href={featuredSampleTender.downloadHref}
            download={featuredSampleTender.fileName}
          >
            <Download size={18} /> Sample Data
          </a>
        </div>

        <button
          className="drop-zone"
          onClick={() => fileInputRef.current?.click()}
          disabled={status === 'uploading' || status === 'processing' || status === 'routing'}
        >
          <input ref={fileInputRef} type="file" accept=".pdf" onChange={handleFileSelect} />
          {fileName ? (
            <>
              <File size={44} />
              <strong>{fileName}</strong>
              <span>Ready for extraction</span>
            </>
          ) : (
            <>
              <UploadCloud size={48} />
              <strong>Select a tender PDF</strong>
              <span>PDF files are accepted for the prototype flow</span>
            </>
          )}
        </button>

        {status === 'idle' || status === 'selected' ? (
          <button className="btn btn-primary full-width" onClick={processFile} disabled={!fileName}>
            <Cpu size={20} /> Extract Criteria
          </button>
        ) : status === 'uploading' || status === 'processing' || status === 'routing' ? (
          <div className={`process-banner ${status}`}>
            <span className="loader-spinner" />
            {status === 'uploading' && 'Uploading tender package'}
            {status === 'processing' && 'Extracting criteria and subcategories'}
            {status === 'routing' && 'Evaluation complete. Opening Priority Queue'}
          </div>
        ) : null}

        {status === 'done' && (
          <section className="extraction-preview">
            <div className="process-banner done">
              <CheckCircle size={20} /> Extraction complete and ready for downstream review
            </div>

            <div className="extraction-preview-head">
              <div>
                <span className="eyebrow">Extraction preview</span>
                <h3>{previewTender?.title || 'Prototype extraction result'}</h3>
                <p>
                  {previewTender
                    ? `${previewTender.gemId} / ${previewTender.department}`
                    : `${fileName} processed into the tender workflow`}
                </p>
              </div>
              <span className="badge success">Evaluation-ready</span>
            </div>

            <div className="extraction-preview-grid">
              <article>
                <span>Criteria Extracted</span>
                <strong>{categories.length}</strong>
                <p>{totalSubcategories} subcategory rules mapped from the tender package.</p>
              </article>
              <article>
                <span>Parsed Documents</span>
                <strong>{previewDocuments.length}</strong>
                <p>Core annexures, BoQ, and technical evidence have been indexed for review.</p>
              </article>
              <article>
                <span>Bid Submissions</span>
                <strong>{previewTender?.bids.length || 0}</strong>
                <p>Bid records are ready to open, compare, score, and move into evaluation.</p>
              </article>
              <article>
                <span>Highest Priority</span>
                <strong>{highestPriorityScore || '--'}</strong>
                <p>The ingested bids are queued with visible priority scores and rationale.</p>
              </article>
            </div>

            <div className="extraction-preview-section">
              <span className="mini-label">Extracted tender clauses</span>
              <div className="extraction-clause-grid">
                {previewHighlights.map((highlight) => (
                  <article className="extraction-clause-card" key={highlight.id}>
                    <span>{highlight.clause}</span>
                    <strong>{highlight.title}</strong>
                    <p>{highlight.detail}</p>
                  </article>
                ))}
              </div>
            </div>

            <div className="extraction-preview-section">
              <span className="mini-label">Detected criteria</span>
              <div className="chip-row">
                {categories.map((category) => (
                  <span className="soft-chip" key={category.id}>{category.name}</span>
                ))}
              </div>
            </div>

            <div className="extraction-preview-section">
              <span className="mini-label">Parsed tender documents</span>
              <div className="doc-grid">
                {previewDocuments.map((documentName) => (
                  <span className="doc-chip static" key={documentName}>
                    <File size={14} />
                    <span>{documentName}</span>
                  </span>
                ))}
              </div>
            </div>

            {!!previewTender?.bids.length && (
              <div className="extraction-preview-section">
                <span className="mini-label">Bid submissions created from this upload</span>
                <div className="preview-bid-grid">
                  {previewTender.bids.map((bid) => (
                    <article className="preview-bid-card" key={bid.id}>
                      <div className="preview-bid-head">
                        <div>
                          <strong>{bid.bidderName}</strong>
                          <span>{bid.id} / {bid.quote}</span>
                        </div>
                        <span className="score-chip">{bid.priorityScore}</span>
                      </div>
                      <p>{bid.priorityReason}</p>
                      <div className="preview-bid-metrics">
                        <span>{bid.status}</span>
                        <span>{bid.score}/100 base score</span>
                        <span>{bid.evaluations.length} criteria</span>
                      </div>
                    </article>
                  ))}
                </div>
              </div>
            )}

            <div className="extraction-preview-actions">
              <button className="btn btn-outline" onClick={openCriteria}>
                Review Criteria
              </button>
              <button className="btn btn-outline" onClick={openBidSubmissions}>
                Open Bid Submissions
              </button>
              <button className="btn btn-primary" onClick={sendToEvaluation}>
                <Cpu size={18} /> Run Evaluation and Open Queue <ArrowRight size={16} />
              </button>
            </div>
          </section>
        )}
      </section>
    </div>
  );
}
