import { useMemo, useState } from 'react';
import {
  ArrowLeft,
  FileText,
  Info,
  MessageSquareWarning,
  ShieldCheck,
  ThumbsDown,
  ThumbsUp,
} from 'lucide-react';
import { useNavigate, useParams } from 'react-router-dom';
import { BidScoreSummary } from '../components/ComplianceAnalytics';
import { DecisionReasonPanel, RejectionReasonDialog } from '../components/DecisionReasonUI';
import { useProcurement } from '../context/ProcurementContext';
import { getOverallStatus } from '../data/procurementData';
import { calculateBidAnalytics } from '../utils/complianceAnalytics';

function verdictClass(status) {
  if (status === 'Eligible' || status === 'Passed') return 'success';
  if (status === 'Not Eligible' || status === 'Failed') return 'danger';
  return 'warning';
}

function getCriteriaSummary(evaluations) {
  const names = evaluations.map((evaluation) => evaluation.criterionName);
  if (names.length <= 3) return names.join(', ');
  return `${names.slice(0, 3).join(', ')}, and ${names.length - 3} more`;
}

function bidBadgeClass(bid) {
  if (bid.decision === 'Rejected') return 'danger';
  if (bid.status === 'Needs Review') return 'warning';
  if (bid.status === 'Pending') return 'neutral';
  return 'success';
}

function TechnicalInsightSidebar({ evaluations, selectedCriterionId, onSelectCriterion }) {
  const passedCount = evaluations.filter((evaluation) => evaluation.status === 'Eligible').length;
  const reviewCount = evaluations.length - passedCount;

  return (
    <aside className="panel bid-technical-sidebar bid-technical-sidebar-left" aria-label="Technical insight">
      <div className="panel-header">
        <div>
          <span className="eyebrow">Technical Insight</span>
          <h3>Evaluation Criteria</h3>
        </div>
        <Info size={20} />
      </div>

      <div className="insight-summary">
        <span>This bid is reviewed against</span>
        <p>{getCriteriaSummary(evaluations)}</p>
      </div>

      <div className="insight-mini-stats">
        <div>
          <strong>{evaluations.length}</strong>
          <span>Criteria</span>
        </div>
        <div>
          <strong>{passedCount}</strong>
          <span>Clear</span>
        </div>
        <div>
          <strong>{reviewCount}</strong>
          <span>Review</span>
        </div>
      </div>

      <div className="insight-focus-chips">
        <span>Budget feasibility</span>
        <span>Timeline readiness</span>
        <span>Past performance</span>
      </div>

      <span className="mini-label">All criteria</span>
      <div className="insight-criteria-list">
        {evaluations.map((evaluation, index) => (
          <button
            className={evaluation.criterionId === selectedCriterionId ? 'active' : ''}
            key={evaluation.criterionId}
            onClick={() => onSelectCriterion(evaluation.criterionId)}
            type="button"
          >
            <span className="insight-rank">{String(index + 1).padStart(2, '0')}</span>
            <div>
              <strong>{evaluation.criterionName}</strong>
              <span>{evaluation.confidence}% confidence</span>
            </div>
            <span className={`badge ${verdictClass(evaluation.status)}`}>{evaluation.status}</span>
          </button>
        ))}
      </div>
    </aside>
  );
}

export default function BidDetail() {
  const { bidId } = useParams();
  const { getBidById, selectTender, updateBidDecision } = useProcurement();
  const navigate = useNavigate();
  const bid = getBidById(bidId);
  const [selectedCriterionId, setSelectedCriterionId] = useState(bid?.evaluations[0]?.criterionId);
  const [rejectionReason, setRejectionReason] = useState(bid?.decision === 'Rejected' ? bid.decisionReason || '' : '');
  const [showRejectDialog, setShowRejectDialog] = useState(false);

  const selectedEvaluation = useMemo(
    () => bid?.evaluations.find((item) => item.criterionId === selectedCriterionId) || bid?.evaluations[0],
    [bid, selectedCriterionId],
  );

  if (!bid) {
    return (
      <div className="empty-state panel">
        <FileText size={42} />
        <h3>Bid not found</h3>
        <button className="btn btn-primary" onClick={() => navigate('/priority')}>Back to Priority Queue</button>
      </div>
    );
  }

  const overallStatus = getOverallStatus(bid.evaluations);
  const bidAnalytics = calculateBidAnalytics(bid);

  const backToQueue = () => {
    selectTender(bid.tenderId);
    navigate('/priority');
  };

  const openRejectDialog = () => {
    setRejectionReason(bid.decision === 'Rejected' ? bid.decisionReason || '' : '');
    setShowRejectDialog(true);
  };

  const closeRejectDialog = () => {
    setShowRejectDialog(false);
    setRejectionReason('');
  };

  const submitRejection = () => {
    if (!rejectionReason.trim()) return;
    updateBidDecision(bid.id, 'Rejected', rejectionReason);
    setShowRejectDialog(false);
  };

  return (
    <div className="stack">
      <section className="panel detail-hero detail-hero-compact">
        <div className="detail-hero-copy">
          <button className="text-button" onClick={backToQueue}>
            <ArrowLeft size={16} /> Back to queue
          </button>
          <span className="eyebrow">{bid.id} / {bid.gemId}</span>
          <h2>{bid.bidderName}</h2>
          <p>{bid.tenderTitle}</p>
        </div>
        <div className="bid-review-toolbar bid-review-toolbar-compact" aria-label="Bid review summary">
          <div className="toolbar-status">
            <span>Status</span>
            <strong>{overallStatus}</strong>
          </div>
          <div className="toolbar-score">
            <span>Compliance</span>
            <strong>{bidAnalytics.complianceScore}<small>/100</small></strong>
          </div>
          <div className="toolbar-risk">
            <span>Risk</span>
            <strong>{bidAnalytics.riskFactor}<small>/100</small></strong>
          </div>
        </div>
      </section>

      <div className="bid-review-shell-left">
        <TechnicalInsightSidebar
          evaluations={bid.evaluations}
          selectedCriterionId={selectedEvaluation.criterionId}
          onSelectCriterion={setSelectedCriterionId}
        />

        <main className="bid-review-main">
          <section className="panel bid-review-card">
            <div className="panel-header">
              <div>
                <span className="eyebrow">Step 1</span>
                <h3>Bid Summary</h3>
              </div>
              <span className={`badge ${bidBadgeClass(bid)}`}>{bid.decision === 'Rejected' ? 'Rejected' : bid.status}</span>
            </div>
            <p className="body-copy">{bid.companyProfile}</p>
            <div className="bid-stats large">
              <div>
                <span>Quote</span>
                <strong>{bid.quote}</strong>
              </div>
              <div>
                <span>Location</span>
                <strong>{bid.location}</strong>
              </div>
              <div>
                <span>Priority Score</span>
                <strong>{bid.priorityScore}</strong>
              </div>
              <div>
                <span>Decision</span>
                <strong>{bid.decision}</strong>
              </div>
            </div>
            <DecisionReasonPanel decision={bid.decision} reason={bid.decisionReason} />
            <BidScoreSummary
              compact
              bid={bid}
              analytics={bidAnalytics}
              overallStatus={overallStatus}
              showTechnicalInsight={false}
            />
          </section>

          <section className="panel bid-review-card">
            <div className="panel-header">
              <div>
                <span className="eyebrow">Step 2</span>
                <h3>Selected Criterion Evidence</h3>
              </div>
              <span className={`badge ${verdictClass(selectedEvaluation.status)}`}>{selectedEvaluation.status}</span>
            </div>

            <div className="selected-criterion-card">
              <div>
                <span className="mini-label">{selectedEvaluation.criterionName}</span>
                <h4>{selectedEvaluation.extractedValue}</h4>
                <p>{selectedEvaluation.explanation}</p>
                <span className="source-pill">{selectedEvaluation.documentRef}</span>
              </div>
              <div className="confidence-meter">
                <span>Evidence confidence</span>
                <strong>{selectedEvaluation.confidence}%</strong>
                <div>
                  <i style={{ width: `${selectedEvaluation.confidence}%` }} />
                </div>
              </div>
            </div>

            <div className="subcheck-grid">
              {selectedEvaluation.subChecks.map((check) => (
                <div className="subcheck-card" key={check.id}>
                  <ShieldCheck size={18} />
                  <div>
                    <strong>{check.name}</strong>
                    <span>{check.evidence}</span>
                  </div>
                  <span className={`badge ${verdictClass(check.status)}`}>{check.status}</span>
                </div>
              ))}
            </div>
          </section>

          <section className="panel bid-review-card">
            <div className="panel-header">
              <div>
                <span className="eyebrow">Step 3</span>
                <h3>Parsed Documents</h3>
              </div>
              <button className="btn btn-outline btn-small" onClick={() => navigate('/evaluation')}>
                Open Report
              </button>
            </div>
            <div className="document-list">
              {bid.documents.map((doc) => (
                <div className="document-row" key={doc.id}>
                  <FileText size={18} />
                  <div>
                    <strong>{doc.name}</strong>
                    <span>{doc.summary}</span>
                  </div>
                  <span className="score-chip">{doc.confidence}%</span>
                </div>
              ))}
            </div>
          </section>

          <section className="panel bid-review-actions-card">
            <div>
              <span className="mini-label">Why this bid is in the queue</span>
              <div className="priority-score-inline">
                <span>Priority Score</span>
                <strong>{bid.priorityScore}</strong>
              </div>
              <p className="body-copy">{bid.priorityReason}</p>
            </div>
            <div className="detail-actions">
              <button className="btn btn-primary" onClick={() => updateBidDecision(bid.id, 'Shortlisted')}>
                <ThumbsUp size={18} /> Shortlist
              </button>
              <button className="btn btn-outline" onClick={() => updateBidDecision(bid.id, 'Clarification Requested')}>
                <MessageSquareWarning size={18} /> Request Clarification
              </button>
              <button className="btn btn-danger" onClick={openRejectDialog}>
                <ThumbsDown size={18} /> Reject
              </button>
            </div>
          </section>
        </main>
      </div>

      <RejectionReasonDialog
        bid={showRejectDialog ? bid : null}
        onChange={setRejectionReason}
        onClose={closeRejectDialog}
        onConfirm={submitRejection}
        reason={rejectionReason}
      />
    </div>
  );
}
