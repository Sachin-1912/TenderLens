import { useMemo, useState } from 'react';
import {
  Check,
  ChevronRight,
  FileCode,
  FileImage,
  FileText,
  Play,
  PlusCircle,
  Search,
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { BidScoreSummary } from '../components/ComplianceAnalytics';
import { DecisionReasonPanel, RejectionReasonDialog } from '../components/DecisionReasonUI';
import { useProcurement } from '../context/ProcurementContext';
import { getOverallStatus } from '../data/procurementData';
import { calculateBidAnalytics } from '../utils/complianceAnalytics';

function getDocIcon(type) {
  if (type === 'PDF') return <FileText size={16} />;
  if (type === 'Scanned') return <FileImage size={16} />;
  return <FileCode size={16} />;
}

function bidBadgeClass(bid) {
  if (bid.decision === 'Rejected') return 'danger';
  if (bid.status === 'Needs Review') return 'warning';
  if (bid.status === 'Pending') return 'neutral';
  return 'success';
}

export default function Bids() {
  const {
    addDemoBidToTender,
    runEvaluation,
    selectTender,
    selectedTender,
    tenders,
    updateBidDecision,
  } = useProcurement();
  const [query, setQuery] = useState('');
  const [selectedDoc, setSelectedDoc] = useState(null);
  const [evaluating, setEvaluating] = useState(false);
  const [rejectionBid, setRejectionBid] = useState(null);
  const [rejectionReason, setRejectionReason] = useState('');
  const navigate = useNavigate();

  const bids = useMemo(() => {
    const normalizedQuery = query.trim().toLowerCase();
    return selectedTender.bids.filter((bid) => {
      if (!normalizedQuery) return true;
      return [bid.bidderName, bid.id, bid.location, bid.decision, bid.status, bid.decisionReason || '']
        .join(' ')
        .toLowerCase()
        .includes(normalizedQuery);
    });
  }, [query, selectedTender]);

  const triggerEvaluation = () => {
    setEvaluating(true);
    window.setTimeout(() => {
      runEvaluation(selectedTender.id);
      setEvaluating(false);
      navigate('/evaluation');
    }, 900);
  };

  const openRejectionDialog = (bid) => {
    setRejectionBid(bid);
    setRejectionReason(bid.decision === 'Rejected' ? bid.decisionReason || '' : '');
  };

  const closeRejectionDialog = () => {
    setRejectionBid(null);
    setRejectionReason('');
  };

  const submitRejection = () => {
    if (!rejectionBid || !rejectionReason.trim()) return;
    updateBidDecision(rejectionBid.id, 'Rejected', rejectionReason);
    closeRejectionDialog();
  };

  return (
    <div className="stack">
      <section className="panel bids-header">
        <div>
          <span className="eyebrow">Bid submissions</span>
          <h2>{selectedTender.title}</h2>
          <p>{selectedTender.department} / {selectedTender.location}</p>
        </div>
        <div className="row-actions">
          <button className="btn btn-outline" onClick={() => addDemoBidToTender(selectedTender.id)}>
            <PlusCircle size={18} /> Add Demo Bid
          </button>
          <button className="btn btn-primary" onClick={triggerEvaluation} disabled={evaluating}>
            {evaluating ? <span className="loader-spinner" /> : <Play size={18} />}
            {evaluating ? 'Analyzing Bids' : 'Run Evaluation'}
          </button>
        </div>
      </section>

      <section className="tender-strip">
        {tenders.map((tender) => (
          <button
            key={tender.id}
            className={`tender-chip ${selectedTender.id === tender.id ? 'active' : ''}`}
            onClick={() => selectTender(tender.id)}
          >
            <strong>{tender.gemId}</strong>
            <span>{tender.category}</span>
          </button>
        ))}
      </section>

      <section className="toolbar panel">
        <label className="search-field wide">
          <Search size={18} />
          <input
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            placeholder="Search bidder, status, location"
          />
        </label>
        <button className="btn btn-outline btn-small" onClick={() => navigate('/criteria')}>
          Review Criteria
        </button>
      </section>

      <section className="bid-card-grid">
        {bids.map((bid) => {
          const bidAnalytics = calculateBidAnalytics(bid);

          return (
            <article key={bid.id} className="panel bid-card">
              <div className="bid-card-top">
                <div>
                  <span className="eyebrow">{bid.id} / {bid.bidderType}</span>
                  <h3>{bid.bidderName}</h3>
                  <p>{bid.companyProfile}</p>
                </div>
                <span className={`badge ${bidBadgeClass(bid)}`}>
                  {bid.decision === 'Rejected' ? 'Rejected' : bid.status}
                </span>
              </div>

              <BidScoreSummary
                bid={bid}
                analytics={bidAnalytics}
                overallStatus={getOverallStatus(bid.evaluations)}
              />

              <div className="bid-stats">
                <div>
                  <span>Quote</span>
                  <strong>{bid.quote}</strong>
                </div>
                <div>
                  <span>Base Score</span>
                  <strong>{bid.score}</strong>
                </div>
                <div>
                  <span>Priority Score</span>
                  <strong>{bid.priorityScore}</strong>
                </div>
                <div>
                  <span>Decision</span>
                  <strong>{bid.decision}</strong>
                </div>
              </div>

              <DecisionReasonPanel decision={bid.decision} reason={bid.decisionReason} />

              <div className="mini-section">
                <span className="mini-label">Priority Rationale</span>
                <p className="body-copy compact">{bid.priorityReason}</p>
              </div>

              <div className="mini-section">
                <span className="mini-label">Strengths</span>
                <div className="chip-row">
                  {bid.strengths.map((item) => (
                    <span className="soft-chip success" key={item}>{item}</span>
                  ))}
                </div>
              </div>

              <div className="mini-section">
                <span className="mini-label">Risk Flags</span>
                <div className="chip-row">
                  {bid.riskFlags.map((item) => (
                    <span className="soft-chip warning" key={item}>{item}</span>
                  ))}
                </div>
              </div>

              <div className="mini-section">
                <span className="mini-label">Parsed Documents</span>
                <div className="doc-grid">
                  {bid.documents.map((doc) => (
                    <button key={doc.id} className="doc-chip" onClick={() => setSelectedDoc({ ...doc, bidderName: bid.bidderName })}>
                      {getDocIcon(doc.type)}
                      <span>{doc.name}</span>
                      <Check size={14} />
                    </button>
                  ))}
                </div>
              </div>

              <div className="bid-card-actions">
                <button className="btn btn-primary" onClick={() => navigate(`/bids/${bid.id}`)}>
                  Open Bid <ChevronRight size={16} />
                </button>
                <button className="btn btn-outline" onClick={() => updateBidDecision(bid.id, 'Clarification Requested')}>
                  Clarify
                </button>
                <button className="btn btn-outline" onClick={() => updateBidDecision(bid.id, 'Shortlisted')}>
                  Shortlist
                </button>
                <button className="btn btn-danger" onClick={() => openRejectionDialog(bid)}>
                  Reject
                </button>
              </div>
            </article>
          );
        })}
      </section>

      {selectedDoc && (
        <section className="panel document-preview">
          <div>
            <span className="eyebrow">{selectedDoc.bidderName}</span>
            <h3>{selectedDoc.name}</h3>
            <p>{selectedDoc.summary}</p>
          </div>
          <span className="score-chip">{selectedDoc.confidence}%</span>
          <button className="btn btn-outline btn-small" onClick={() => setSelectedDoc(null)}>
            Close
          </button>
        </section>
      )}

      {bids.length === 0 && (
        <div className="empty-state panel">
          <Search size={36} />
          <h3>No bid submissions match this search.</h3>
          <button className="btn btn-outline" onClick={() => setQuery('')}>Clear Search</button>
        </div>
      )}

      <RejectionReasonDialog
        bid={rejectionBid}
        onChange={setRejectionReason}
        onClose={closeRejectionDialog}
        onConfirm={submitRejection}
        reason={rejectionReason}
      />
    </div>
  );
}
