import { Fragment, useMemo, useState } from 'react';
import {
  AlertCircle,
  AlertTriangle,
  CheckCircle,
  ChevronDown,
  ChevronRight,
  Download,
  Play,
  XCircle,
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { BidScoreSummary } from '../components/ComplianceAnalytics';
import { DecisionReasonPanel, RejectionReasonDialog } from '../components/DecisionReasonUI';
import { useProcurement } from '../context/ProcurementContext';
import { getOverallStatus } from '../data/procurementData';
import { calculateBidAnalytics } from '../utils/complianceAnalytics';

function statusClass(status) {
  if (status === 'Eligible') return 'success';
  if (status === 'Not Eligible') return 'danger';
  return 'warning';
}

function statusIcon(status) {
  if (status === 'Eligible') return <CheckCircle size={18} />;
  if (status === 'Not Eligible') return <XCircle size={18} />;
  return <AlertCircle size={18} />;
}

function decisionBadgeClass(decision) {
  if (decision === 'Rejected') return 'danger';
  if (decision === 'Shortlisted') return 'success';
  if (decision === 'Clarification Requested') return 'warning';
  return 'neutral';
}

export default function EvaluationReport() {
  const {
    runEvaluation,
    selectTender,
    selectedTender,
    tenders,
    updateBidDecision,
  } = useProcurement();
  const [expanded, setExpanded] = useState({});
  const [rejectionBid, setRejectionBid] = useState(null);
  const [rejectionReason, setRejectionReason] = useState('');
  const navigate = useNavigate();

  const reportRows = useMemo(
    () => selectedTender.bids.map((bid) => ({
      bid,
      bidAnalytics: calculateBidAnalytics(bid),
      overallStatus: getOverallStatus(bid.evaluations),
    })),
    [selectedTender],
  );
  const needsManualReview = reportRows.some((row) => row.overallStatus === 'Needs Manual Review');

  const exportReport = () => {
    const payload = {
      tender: {
        id: selectedTender.id,
        gemId: selectedTender.gemId,
        title: selectedTender.title,
      },
      generatedAt: new Date().toISOString(),
      bids: reportRows,
    };
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${selectedTender.id}-evaluation-report.json`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const openRejectionDialog = (bid) => {
    setRejectionBid(bid);
    setRejectionReason(bid.decision === 'Rejected' ? bid.decisionReason || '' : '');
  };

  const closeRejectionDialog = () => {
    setRejectionBid(null);
    setRejectionReason('');
  };

  const submitRejection = () => {
    if (!rejectionBid || !rejectionReason.trim()) return;
    updateBidDecision(rejectionBid.id, 'Rejected', rejectionReason);
    closeRejectionDialog();
  };

  return (
    <div className="stack">
      <section className="panel report-header">
        <div>
          <span className="eyebrow">Intelligence report</span>
          <h2>{selectedTender.title}</h2>
          <p>{selectedTender.gemId} / {selectedTender.department}</p>
        </div>
        <div className="row-actions">
          <button className="btn btn-outline" onClick={() => runEvaluation(selectedTender.id)}>
            <Play size={18} /> Re-run Evaluation
          </button>
          <button className="btn btn-primary" onClick={exportReport}>
            <Download size={18} /> Export Report
          </button>
        </div>
      </section>

      <section className="tender-strip">
        {tenders.map((tender) => (
          <button
            key={tender.id}
            className={`tender-chip ${selectedTender.id === tender.id ? 'active' : ''}`}
            onClick={() => selectTender(tender.id)}
          >
            <strong>{tender.gemId}</strong>
            <span>{tender.subcategory}</span>
          </button>
        ))}
      </section>

      {needsManualReview && (
        <section className="callout warning">
          <div className="callout-icon">
            <AlertTriangle size={22} />
          </div>
          <div>
            <span className="eyebrow">Officer action needed</span>
            <h3>Some bidder evidence needs manual review before final award recommendation.</h3>
            <p>Open a row to inspect the specific category, source document, confidence score, and subcheck status.</p>
          </div>
        </section>
      )}

      <section className="panel queue-table">
        <div className="table-shell">
          <table>
            <thead>
              <tr>
                <th></th>
                <th>Bidder Entity</th>
                <th>Quote</th>
                <th>Overall Verdict</th>
                <th>Officer Decision</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {reportRows.map(({ bid, bidAnalytics, overallStatus }) => (
                <Fragment key={bid.id}>
                  <tr>
                    <td>
                      <button
                        className="icon-btn neutral"
                        onClick={() => setExpanded((current) => ({ ...current, [bid.id]: !current[bid.id] }))}
                      >
                        {expanded[bid.id] ? <ChevronDown size={18} /> : <ChevronRight size={18} />}
                      </button>
                    </td>
                    <td>
                      <div className="table-bid-stack">
                        <button className="table-link" onClick={() => navigate(`/bids/${bid.id}`)}>
                          <strong>{bid.bidderName}</strong>
                          <span>{bid.id}</span>
                        </button>
                        <BidScoreSummary
                          compact
                          bid={bid}
                          analytics={bidAnalytics}
                          overallStatus={overallStatus}
                        />
                      </div>
                    </td>
                    <td className="strong">{bid.quote}</td>
                    <td><span className={`badge ${statusClass(overallStatus)}`}>{overallStatus}</span></td>
                    <td><span className={`badge ${decisionBadgeClass(bid.decision)}`}>{bid.decision}</span></td>
                    <td>
                      <div className="row-actions">
                        <button className="btn btn-outline btn-small" onClick={() => updateBidDecision(bid.id, 'Clarification Requested')}>
                          Clarify
                        </button>
                        <button className="btn btn-primary btn-small" onClick={() => updateBidDecision(bid.id, 'Shortlisted')}>
                          Approve
                        </button>
                        <button className="btn btn-danger btn-small" onClick={() => openRejectionDialog(bid)}>
                          Reject
                        </button>
                      </div>
                    </td>
                  </tr>
                  {expanded[bid.id] && (
                    <tr>
                      <td colSpan={6} className="expanded-cell">
                        <div className="report-breakdown-stack">
                          <DecisionReasonPanel decision={bid.decision} reason={bid.decisionReason} />
                        <div className="report-breakdown">
                          {bid.evaluations.map((evaluation) => (
                            <div className="report-item" key={evaluation.criterionId}>
                              <div>
                                {statusIcon(evaluation.status)}
                                <strong>{evaluation.criterionName}</strong>
                              </div>
                              <span className={`badge ${statusClass(evaluation.status)}`}>{evaluation.status}</span>
                              <span className="score-chip">{evaluation.confidence}%</span>
                              <p>{evaluation.explanation}</p>
                              <em>{evaluation.documentRef}</em>
                            </div>
                          ))}
                        </div>
                        </div>
                      </td>
                    </tr>
                  )}
                </Fragment>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      <RejectionReasonDialog
        bid={rejectionBid}
        onChange={setRejectionReason}
        onClose={closeRejectionDialog}
        onConfirm={submitRejection}
        reason={rejectionReason}
      />
    </div>
  );
}
