import { useMemo, useState } from 'react';
import { ArrowDownUp, Eye, Filter, Search, Star, Zap } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useProcurement } from '../context/ProcurementContext';

function getPriorityTone(level) {
  if (level === 'Critical') return 'danger';
  if (level === 'High') return 'warning';
  if (level === 'Medium') return 'info';
  return 'success';
}

function daysLeft(deadline) {
  const oneDay = 24 * 60 * 60 * 1000;
  const diff = new Date(deadline).setHours(0, 0, 0, 0) - new Date().setHours(0, 0, 0, 0);
  return Math.ceil(diff / oneDay);
}

export default function PriorityQueue() {
  const { allBids, selectTender, tenders, updateBidDecision } = useProcurement();
  const [category, setCategory] = useState('All');
  const [status, setStatus] = useState('All');
  const [sortMode, setSortMode] = useState('priority');
  const [query, setQuery] = useState('');
  const navigate = useNavigate();

  const categories = ['All', ...new Set(allBids.map((bid) => bid.category))];
  const statuses = ['All', 'Pending', 'Needs Review', 'Evaluated'];

  const filteredBids = useMemo(() => {
    const normalizedQuery = query.trim().toLowerCase();
    return allBids
      .filter((bid) => category === 'All' || bid.category === category)
      .filter((bid) => status === 'All' || bid.status === status)
      .filter((bid) => {
        if (!normalizedQuery) return true;
        return [bid.bidderName, bid.tenderTitle, bid.gemId, bid.subcategory, bid.id]
          .join(' ')
          .toLowerCase()
          .includes(normalizedQuery);
      })
      .sort((a, b) => {
        if (sortMode === 'deadline') return new Date(a.deadline) - new Date(b.deadline);
        if (sortMode === 'quote') return a.quoteValue - b.quoteValue;
        return b.priorityScore - a.priorityScore;
      });
  }, [allBids, category, query, sortMode, status]);

  const openBid = (bid) => {
    selectTender(bid.tenderId);
    navigate(`/bids/${bid.id}`);
  };

  return (
    <div className="stack">
      <section className="callout dark">
        <div className="callout-icon">
          <Zap size={24} />
        </div>
        <div>
          <span className="eyebrow">Priority Queue</span>
          <h2>Realistic bid submissions sorted by urgency, value, risk, and review effort.</h2>
          <p>
            Open any bid to show the full tender, bidder profile, documents, category evidence,
            and officer decision controls.
          </p>
        </div>
      </section>

      <section className="toolbar panel">
        <label className="search-field">
          <Search size={18} />
          <input
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            placeholder="Search bidder, GeM ID, tender, category"
          />
        </label>

        <label className="select-field">
          <Filter size={16} />
          <select value={category} onChange={(event) => setCategory(event.target.value)}>
            {categories.map((item) => (
              <option key={item}>{item}</option>
            ))}
          </select>
        </label>

        <label className="select-field">
          <Star size={16} />
          <select value={status} onChange={(event) => setStatus(event.target.value)}>
            {statuses.map((item) => (
              <option key={item}>{item}</option>
            ))}
          </select>
        </label>

        <label className="select-field">
          <ArrowDownUp size={16} />
          <select value={sortMode} onChange={(event) => setSortMode(event.target.value)}>
            <option value="priority">Priority score</option>
            <option value="deadline">Deadline</option>
            <option value="quote">Lowest quote</option>
          </select>
        </label>
      </section>

      <section className="queue-table panel">
        <div className="table-shell">
          <table>
            <thead>
              <tr>
                <th>Rank</th>
                <th>Bid and Tender</th>
                <th>Category</th>
                <th>Quote</th>
                <th>Deadline</th>
                <th>Priority</th>
                <th>Status</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredBids.map((bid, index) => {
                const tender = tenders.find((item) => item.id === bid.tenderId);
                return (
                  <tr key={bid.id}>
                    <td>
                      <div className="rank-cell">
                        <span>{String(index + 1).padStart(2, '0')}</span>
                        <strong>{bid.priorityScore}</strong>
                      </div>
                    </td>
                    <td>
                      <div className="table-title">
                        <strong>{bid.bidderName}</strong>
                        <span>{bid.id} / {bid.gemId}</span>
                        <small>{bid.tenderTitle}</small>
                      </div>
                    </td>
                    <td>
                      <div className="table-title compact">
                        <strong>{bid.category}</strong>
                        <span>{bid.subcategory}</span>
                      </div>
                    </td>
                    <td className="strong">{bid.quote}</td>
                    <td>
                      <div className="table-title compact">
                        <strong>{bid.deadline}</strong>
                        <span>{daysLeft(bid.deadline)} days left</span>
                      </div>
                    </td>
                    <td>
                      <span className={`badge ${getPriorityTone(tender?.priorityLevel)}`}>
                        {tender?.priorityLevel}
                      </span>
                    </td>
                    <td>
                      <span className={`badge ${bid.status === 'Needs Review' ? 'warning' : bid.status === 'Pending' ? 'neutral' : 'success'}`}>
                        {bid.status}
                      </span>
                    </td>
                    <td>
                      <div className="row-actions">
                        <button className="btn btn-primary btn-small" onClick={() => openBid(bid)}>
                          <Eye size={15} /> Open
                        </button>
                        <button className="btn btn-outline btn-small" onClick={() => updateBidDecision(bid.id, 'Shortlisted')}>
                          Shortlist
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {filteredBids.length === 0 && (
          <div className="empty-state">
            <Search size={36} />
            <h3>No bids match the current filters.</h3>
            <button className="btn btn-outline" onClick={() => { setQuery(''); setCategory('All'); setStatus('All'); }}>
              Clear Filters
            </button>
          </div>
        )}
      </section>
    </div>
  );
}
