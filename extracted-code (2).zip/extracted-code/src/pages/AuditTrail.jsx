import { useMemo, useState } from 'react';
import { Download, Search, ShieldAlert, ShieldCheck } from 'lucide-react';
import { useProcurement } from '../context/ProcurementContext';

export default function AuditTrail() {
  const { auditLogs } = useProcurement();
  const [type, setType] = useState('All');
  const [query, setQuery] = useState('');

  const actionTypes = ['All', ...new Set(auditLogs.map((log) => log.actionType))];
  const visibleLogs = useMemo(() => {
    const normalizedQuery = query.trim().toLowerCase();
    return auditLogs
      .filter((log) => type === 'All' || log.actionType === type)
      .filter((log) => {
        if (!normalizedQuery) return true;
        return [log.description, log.actor, log.tenderId, log.bidId, log.hash].join(' ').toLowerCase().includes(normalizedQuery);
      });
  }, [auditLogs, query, type]);

  const exportLogs = () => {
    const blob = new Blob([JSON.stringify(visibleLogs, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'evalpro-audit-trail.json';
    link.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="stack">
      <section className="panel report-header">
        <div>
          <span className="eyebrow">Audit trail</span>
          <h2>Immutable Action Log</h2>
          <p>Every upload, category edit, GPT-style evaluation, and officer decision is captured for the demo.</p>
        </div>
        <button className="btn btn-primary" onClick={exportLogs}>
          <Download size={18} /> Export Logs
        </button>
      </section>

      <section className="toolbar panel">
        <label className="search-field wide">
          <Search size={18} />
          <input
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            placeholder="Search actor, tender, bid, hash"
          />
        </label>
        <div className="segmented">
          {actionTypes.map((item) => (
            <button key={item} className={type === item ? 'active' : ''} onClick={() => setType(item)}>
              {item}
            </button>
          ))}
        </div>
      </section>

      <section className="panel audit-panel">
        <div className="audit-line">
          {visibleLogs.map((log) => (
            <article className="audit-item" key={log.id}>
              <div className="audit-dot" />
              <div className="audit-card">
                <div className="audit-meta">
                  <span>{new Date(log.timestamp).toLocaleString()}</span>
                  <span className="badge neutral">{log.actionType}</span>
                  <span className="actor-pill"><ShieldCheck size={15} /> {log.actor}</span>
                </div>
                <h3>{log.description}</h3>
                <div className="audit-refs">
                  {log.tenderId && <span>Tender: {log.tenderId}</span>}
                  {log.bidId && <span>Bid: {log.bidId}</span>}
                  <span>Hash: {log.hash}</span>
                </div>
              </div>
            </article>
          ))}
        </div>

        {visibleLogs.length === 0 && (
          <div className="empty-state">
            <ShieldAlert size={42} />
            <h3>No audit entries match this view.</h3>
            <button className="btn btn-outline" onClick={() => { setType('All'); setQuery(''); }}>
              Clear Filters
            </button>
          </div>
        )}
      </section>
    </div>
  );
}
