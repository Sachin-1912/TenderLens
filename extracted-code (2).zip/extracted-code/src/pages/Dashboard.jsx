import {
  AlertCircle,
  AlertTriangle,
  Check,
  CheckCircle,
  Cpu,
  FileCheck,
  FileText,
  ListOrdered,
  Users,
  X,
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useProcurement } from '../context/ProcurementContext';
import { calculateBidAnalytics } from '../utils/complianceAnalytics';

function countStatuses(items) {
  return items.reduce(
    (counts, item) => {
      counts[item.status] = (counts[item.status] || 0) + 1;
      return counts;
    },
    { Passed: 0, Flagged: 0, Pending: 0 },
  );
}

export default function Dashboard() {
  const { allBids, categories, tenders } = useProcurement();
  const navigate = useNavigate();

  const needsReview = allBids.filter((bid) => bid.status === 'Needs Review' || bid.decision === 'Under Review').length;
  const evaluated = allBids.filter((bid) => bid.status === 'Evaluated').length;
  const topQueue = [...allBids].sort((a, b) => b.priorityScore - a.priorityScore).slice(0, 4);

  const statCards = [
    {
      title: 'Active Tenders',
      value: tenders.length,
      icon: FileText,
      tone: 'indigo',
      action: () => navigate('/priority'),
    },
    {
      title: 'Submitted Bids',
      value: allBids.length,
      icon: Users,
      tone: 'cyan',
      action: () => navigate('/bids'),
    },
    {
      title: 'Evaluated',
      value: evaluated,
      icon: CheckCircle,
      tone: 'green',
      action: () => navigate('/evaluation'),
    },
    {
      title: 'Needs Review',
      value: needsReview,
      icon: AlertTriangle,
      tone: 'red',
      action: () => navigate('/priority'),
    },
  ];

  return (
    <div className="stack">
      <section className="dashboard-hero">
        <div>
          <span className="eyebrow">Hackathon demo workspace</span>
          <h2>AI-assisted tender evaluation with clickable bid workflows.</h2>
          <p>
            The demo contains realistic procurement bids, category review controls, officer decisions,
            exportable reports, and an audit trail.
          </p>
        </div>
        <button className="btn btn-primary" onClick={() => navigate('/priority')}>
          <ListOrdered size={18} /> Open Priority Queue
        </button>
      </section>

      <section className="metric-grid">
        {statCards.map((card) => {
          const Icon = card.icon;
          return (
            <button className={`metric-card tone-${card.tone}`} key={card.title} onClick={card.action}>
              <div>
                <span>{card.title}</span>
                <strong>{card.value}</strong>
              </div>
              <Icon size={30} />
            </button>
          );
        })}
      </section>

      <section className="split-grid">
        <div className="panel">
          <div className="panel-header">
            <div>
              <span className="eyebrow">Next bids to open</span>
              <h3>Priority Queue Preview</h3>
            </div>
            <button className="btn btn-outline btn-small" onClick={() => navigate('/priority')}>
              View All
            </button>
          </div>
          <div className="queue-list">
            {topQueue.map((bid, index) => {
              const bidAnalytics = calculateBidAnalytics(bid);

              return (
                <button className="queue-preview-row" key={bid.id} onClick={() => navigate(`/bids/${bid.id}`)}>
                  <span className="rank">{String(index + 1).padStart(2, '0')}</span>
                  <div>
                    <strong>{bid.bidderName}</strong>
                    <span>{bid.tenderTitle}</span>
                    <span className="queue-score-line">
                      Compliance {bidAnalytics.complianceScore}/100 - Risk {bidAnalytics.riskFactor}/100
                    </span>
                  </div>
                  <span className="score-chip">{bid.priorityScore}</span>
                </button>
              );
            })}
          </div>
        </div>

        <div className="panel">
          <div className="panel-header">
            <div>
              <span className="eyebrow">Evaluation categories</span>
              <h3>9-Criteria Matrix</h3>
            </div>
            <button className="btn btn-outline btn-small" onClick={() => navigate('/criteria')}>
              Review
            </button>
          </div>
          <div className="category-mini-grid">
            {categories.slice(0, 6).map((category) => {
              const counts = countStatuses(category.subcategories);
              return (
                <button
                  className="category-mini-card"
                  key={category.id}
                  onClick={() => navigate(`/criteria?category=${category.id}`)}
                >
                  <span>{String(category.number).padStart(2, '0')}</span>
                  <strong>{category.name}</strong>
                  <div className="status-counts">
                    <span className="ok"><Check size={14} /> {counts.Passed}</span>
                    <span className="warn"><AlertCircle size={14} /> {counts.Pending}</span>
                    <span className="bad"><X size={14} /> {counts.Flagged}</span>
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      </section>

      <section>
        <div className="section-heading">
          <div>
            <span className="eyebrow">Category drilldown</span>
            <h3>Categories and Subcategories</h3>
          </div>
        </div>
        <div className="category-grid">
          {categories.map((category) => {
            const counts = countStatuses(category.subcategories);
            const Icon = category.type === 'GPT Assessed' ? Cpu : FileCheck;
            return (
              <button
                key={category.id}
                className="category-card"
                onClick={() => navigate(`/criteria?category=${category.id}`)}
              >
                <div className="category-card-top">
                  <span className="badge neutral">{category.type}</span>
                  <Icon size={22} />
                </div>
                <h4>
                  <span>{String(category.number).padStart(2, '0')}</span>
                  {category.name}
                </h4>
                <p>{category.description}</p>
                <div className="status-counts">
                  <span className="ok"><Check size={16} /> {counts.Passed} passed</span>
                  <span className="warn"><AlertCircle size={16} /> {counts.Pending} pending</span>
                  <span className="bad"><X size={16} /> {counts.Flagged} flagged</span>
                </div>
              </button>
            );
          })}
        </div>
      </section>
    </div>
  );
}
