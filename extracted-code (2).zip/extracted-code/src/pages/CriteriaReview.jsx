import { useMemo, useState } from 'react';
import { Check, CheckCircle, Cpu, FileCheck, Lock, Save, Search, X } from 'lucide-react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { useProcurement } from '../context/ProcurementContext';

function statusClass(status) {
  if (status === 'Passed') return 'success';
  if (status === 'Flagged') return 'danger';
  return 'warning';
}

export default function CriteriaReview() {
  const {
    categories,
    lockCriteria,
    selectedTender,
    updateCriterionStatus,
    updateCriterionThreshold,
  } = useProcurement();
  const [params, setParams] = useSearchParams();
  const [filter, setFilter] = useState('All');
  const [query, setQuery] = useState('');
  const navigate = useNavigate();
  const extractionSummary = selectedTender.extractionSummary;

  const selectedCategoryId = params.get('category') || categories[0]?.id;
  const selectedCategory = categories.find((category) => category.id === selectedCategoryId) || categories[0];

  const visibleSubcategories = useMemo(() => {
    const normalizedQuery = query.trim().toLowerCase();
    return selectedCategory.subcategories
      .filter((item) => filter === 'All' || item.status === filter)
      .filter((item) => {
        if (!normalizedQuery) return true;
        return [item.name, item.requirement, item.threshold, item.method].join(' ').toLowerCase().includes(normalizedQuery);
      });
  }, [filter, query, selectedCategory]);

  const lockAndProceed = () => {
    lockCriteria(selectedTender.id);
    navigate('/bids');
  };

  return (
    <div className="stack">
      <section className="panel criteria-header">
        <div>
          <span className="eyebrow">{selectedTender.gemId}</span>
          <h2>Review extracted categories and subcategories</h2>
          <p>{selectedTender.title}</p>
        </div>
        <button className="btn btn-primary" onClick={lockAndProceed}>
          <Lock size={18} /> Lock Criteria and Proceed
        </button>
      </section>

      {extractionSummary && (
        <section className="panel extracted-summary-panel">
          <div className="extracted-summary-head">
            <div>
              <span className="eyebrow">Tender extraction</span>
              <h3>{extractionSummary.sourceFileName}</h3>
              <p>The uploaded tender package has been parsed into operational clauses, eligibility rules, and evaluation-ready document sets.</p>
            </div>
            <div className="extracted-summary-stats">
              <div>
                <span>Documents</span>
                <strong>{extractionSummary.previewDocuments.length}</strong>
              </div>
              <div>
                <span>Focus clauses</span>
                <strong>{extractionSummary.criteriaHighlights.length}</strong>
              </div>
              <div>
                <span>Budget</span>
                <strong>{selectedTender.budget}</strong>
              </div>
            </div>
          </div>

          <div className="extraction-clause-grid">
            {extractionSummary.criteriaHighlights.map((highlight) => (
              <article className="extraction-clause-card" key={highlight.id}>
                <span>{highlight.clause}</span>
                <strong>{highlight.title}</strong>
                <p>{highlight.detail}</p>
              </article>
            ))}
          </div>
        </section>
      )}

      <section className="criteria-layout">
        <aside className="panel category-sidebar">
          <div className="sidebar-title">Categories</div>
          {categories.map((category) => {
            const flagged = category.subcategories.filter((item) => item.status === 'Flagged').length;
            return (
              <button
                key={category.id}
                className={`category-tab ${category.id === selectedCategory.id ? 'active' : ''}`}
                onClick={() => setParams({ category: category.id })}
              >
                <span>{String(category.number).padStart(2, '0')}</span>
                <strong>{category.name}</strong>
                {flagged > 0 && <em>{flagged}</em>}
              </button>
            );
          })}
        </aside>

        <div className="stack">
          <section className="panel selected-category-card">
            <div className="selected-category-main">
              <div className="category-icon">
                {selectedCategory.type === 'GPT Assessed' ? <Cpu size={24} /> : <FileCheck size={24} />}
              </div>
              <div>
                <span className="eyebrow">{selectedCategory.type}</span>
                <h3>{selectedCategory.name}</h3>
                <p>{selectedCategory.description}</p>
              </div>
            </div>

            <div className="toolbar tight">
              <label className="search-field">
                <Search size={16} />
                <input
                  value={query}
                  onChange={(event) => setQuery(event.target.value)}
                  placeholder="Search subcategories"
                />
              </label>
              <div className="segmented">
                {['All', 'Passed', 'Pending', 'Flagged'].map((item) => (
                  <button
                    key={item}
                    className={filter === item ? 'active' : ''}
                    onClick={() => setFilter(item)}
                  >
                    {item}
                  </button>
                ))}
              </div>
            </div>
          </section>

          <section className="subcategory-grid">
            {visibleSubcategories.map((subcategory) => (
              <article className="panel subcategory-card" key={subcategory.id}>
                <div className="subcategory-top">
                  <span className={`badge ${statusClass(subcategory.status)}`}>{subcategory.status}</span>
                  <span className="badge neutral">{subcategory.method}</span>
                </div>

                <h4>{subcategory.name}</h4>
                <p>{subcategory.requirement}</p>

                <label className="threshold-field">
                  <span>Threshold / rule</span>
                  <textarea
                    value={subcategory.threshold}
                    onChange={(event) => updateCriterionThreshold(selectedCategory.id, subcategory.id, event.target.value)}
                    rows={2}
                  />
                </label>

                <div className="subcategory-footer">
                  <span>{subcategory.mandatory ? 'Mandatory' : 'Optional'}</span>
                  <div className="row-actions">
                    <button className="icon-btn success" title="Mark passed" onClick={() => updateCriterionStatus(selectedCategory.id, subcategory.id, 'Passed')}>
                      <Check size={16} />
                    </button>
                    <button className="icon-btn warning" title="Mark pending" onClick={() => updateCriterionStatus(selectedCategory.id, subcategory.id, 'Pending')}>
                      <Save size={16} />
                    </button>
                    <button className="icon-btn danger" title="Flag issue" onClick={() => updateCriterionStatus(selectedCategory.id, subcategory.id, 'Flagged')}>
                      <X size={16} />
                    </button>
                  </div>
                </div>
              </article>
            ))}
          </section>

          {visibleSubcategories.length === 0 && (
            <div className="empty-state panel">
              <CheckCircle size={36} />
              <h3>No subcategories match this view.</h3>
              <button className="btn btn-outline" onClick={() => { setQuery(''); setFilter('All'); }}>
                Clear Filters
              </button>
            </div>
          )}
        </div>
      </section>
    </div>
  );
}
