import { Info } from 'lucide-react';

function getComplianceVerdict(score) {
  if (score >= 82) {
    return {
      tone: 'strong',
      label: 'Strong compliance',
      description: 'This bid clears most required checks with reliable evidence.',
    };
  }

  if (score >= 66) {
    return {
      tone: 'steady',
      label: 'Good, with review points',
      description: 'This bid is mostly compliant, but a few criteria still need officer attention.',
    };
  }

  return {
    tone: 'attention',
    label: 'Needs review',
    description: 'This bid has failed or uncertain checks that need closer review.',
  };
}

function getCriterionNames(bid) {
  return (bid?.evaluations || []).map((evaluation) => evaluation.criterionName);
}

export function ComplianceGauge({
  score,
  label = 'Bid Compliance',
  sublabel,
  detailLines = [
    '9 criteria evaluated',
    'Evidence confidence included',
    'Eligibility status included',
  ],
  compact = false,
}) {
  const safeScore = Math.max(0, Math.min(100, score));
  const verdict = getComplianceVerdict(safeScore);

  return (
    <div className={`compliance-gauge ${compact ? 'compact' : ''}`}>
      <div className={`compliance-meter tone-${verdict.tone}`}>
        <div className="meter-header">
          <div>
            <span className="meter-kicker">Per-bid meter</span>
            <h4>{label}</h4>
            {sublabel && <p>{sublabel}</p>}
          </div>
          <div className="meter-score">
            <strong>{safeScore}</strong>
            <span>/100</span>
          </div>
        </div>

        <div
          className="meter-bar"
          role="meter"
          aria-label={`${label}: ${safeScore} out of 100`}
          aria-valuemin="0"
          aria-valuemax="100"
          aria-valuenow={safeScore}
        >
          <i style={{ width: `${safeScore}%` }} />
        </div>

        <div className="meter-scale">
          <span>Needs review</span>
          <span>Good</span>
          <span>Strong</span>
        </div>

        <div className="meter-verdict">
          <strong>{verdict.label}</strong>
          <p>{verdict.description}</p>
        </div>

        <div className="meter-detail-lines">
          {detailLines.map((line) => (
            <span key={line}>{line}</span>
          ))}
        </div>
      </div>
    </div>
  );
}

export function BidScoreSummary({ bid, analytics, overallStatus, compact = false, showTechnicalInsight = true }) {
  const complianceScore = Math.max(0, Math.min(100, analytics.complianceScore));
  const compliance = getComplianceVerdict(complianceScore);
  const criterionNames = getCriterionNames(bid);
  const tooltipId = bid ? `technical-insight-${bid.id}` : undefined;

  return (
    <div className={`bid-score-summary ${compact ? 'compact' : ''}`}>
      <div className="bid-score-head">
        <div className="bid-score-title">
          <span>Bid scoring</span>
          {showTechnicalInsight && criterionNames.length > 0 && (
            <div className="technical-insight">
              <button className="technical-insight-trigger" type="button" aria-describedby={tooltipId}>
                <Info size={14} />
                <span>Technical Insight</span>
              </button>
              <div className="technical-insight-tooltip" id={tooltipId} role="tooltip">
                <strong>Evaluating based on:</strong>
                <div>
                  {criterionNames.map((name) => (
                    <span key={name}>{name}</span>
                  ))}
                </div>
                <p>Compliance blends each criterion verdict, evidence confidence, and the bid base score.</p>
              </div>
            </div>
          )}
        </div>
        {overallStatus && <strong>{overallStatus}</strong>}
      </div>

      <div className="bid-score-grid">
        <div className={`bid-score-block compliance tone-${compliance.tone}`}>
          <div className="score-row">
            <span>Compliance Score</span>
            <strong>{complianceScore}/100</strong>
          </div>
          <div className="score-meter compliance-meter-line">
            <i style={{ width: `${complianceScore}%` }} />
          </div>
          <p>{compliance.label} - 9 criteria, evidence confidence, and eligibility status.</p>
        </div>
      </div>

      {bid && (
        <div className="bid-score-foot">
          <span>{bid.evaluations.length} criteria checked</span>
          <span>{analytics.flaggedCount} review flags</span>
          <span>{analytics.averageConfidence}% evidence confidence</span>
        </div>
      )}
    </div>
  );
}
