import { AlertTriangle, ThumbsDown, X } from 'lucide-react';

const rejectionTemplates = [
  'Mandatory OEM authorization could not be validated from the submitted documents.',
  'Commercial submission deviates from the tender terms and budget conditions.',
  'Critical eligibility documents are missing or materially incomplete.',
  'Past performance evidence does not satisfy the minimum tender requirement.',
];

export function DecisionReasonPanel({ decision, reason, title }) {
  if (!reason) return null;

  const label = title || (decision === 'Rejected' ? 'Rejection reason' : 'Officer note');

  return (
    <section className={`decision-note ${decision === 'Rejected' ? 'danger' : 'neutral'}`}>
      <span className="decision-note-label">{label}</span>
      <p>{reason}</p>
    </section>
  );
}

export function RejectionReasonDialog({ bid, reason, onChange, onClose, onConfirm }) {
  if (!bid) return null;

  return (
    <div className="dialog-backdrop" onClick={onClose} role="presentation">
      <section
        aria-labelledby="reject-dialog-title"
        aria-modal="true"
        className="panel rejection-dialog"
        onClick={(event) => event.stopPropagation()}
        role="dialog"
      >
        <div className="dialog-header">
          <div>
            <span className="eyebrow">Officer decision</span>
            <h3 id="reject-dialog-title">Reject {bid.bidderName}</h3>
            <p>Capture a clear reason so the rejection is visible in bid review, reporting, and audit history.</p>
          </div>
          <button className="icon-btn neutral" onClick={onClose} type="button">
            <X size={16} />
          </button>
        </div>

        <div className="dialog-callout">
          <AlertTriangle size={18} />
          <span>{bid.id} / {bid.tenderTitle}</span>
        </div>

        <div className="reason-template-row">
          {rejectionTemplates.map((template) => (
            <button
              className={`soft-chip ${reason === template ? 'active' : ''}`}
              key={template}
              onClick={() => onChange(template)}
              type="button"
            >
              {template}
            </button>
          ))}
        </div>

        <label className="reason-input">
          <span>Reason for rejection</span>
          <textarea
            onChange={(event) => onChange(event.target.value)}
            placeholder="Explain why this bid is being rejected."
            rows={5}
            value={reason}
          />
        </label>

        <div className="dialog-actions">
          <button className="btn btn-outline" onClick={onClose} type="button">
            Cancel
          </button>
          <button className="btn btn-danger" disabled={!reason.trim()} onClick={onConfirm} type="button">
            <ThumbsDown size={18} /> Save Rejection
          </button>
        </div>
      </section>
    </div>
  );
}
