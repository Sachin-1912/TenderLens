export const evaluationCategories = [
  {
    id: 'technical',
    number: 1,
    name: 'Technical Aspect',
    type: 'GPT Assessed',
    description: 'Capability, specification match, architecture quality, warranty, and implementation readiness.',
    subcategories: [
      {
        id: 'spec-match',
        name: 'Specification Compliance',
        requirement: 'Matches all mandatory technical specifications from the tender document.',
        method: 'AI-assessed',
        mandatory: true,
        threshold: '90% or higher spec match',
        status: 'Passed',
      },
      {
        id: 'implementation-plan',
        name: 'Implementation Plan',
        requirement: 'Provides deployment plan, acceptance testing, training, and support workflow.',
        method: 'AI-assessed',
        mandatory: true,
        threshold: 'Complete plan with named milestones',
        status: 'Flagged',
      },
      {
        id: 'warranty-support',
        name: 'Warranty and Support',
        requirement: 'Meets warranty period, replacement SLA, and helpdesk requirements.',
        method: 'Document',
        mandatory: true,
        threshold: '3 year warranty and 24 hour replacement SLA',
        status: 'Passed',
      },
    ],
  },
  {
    id: 'financial',
    number: 2,
    name: 'Financial Aspect',
    type: 'GPT Assessed',
    description: 'Quoted value, price realism, tax inclusion, payment terms, and value-for-money signals.',
    subcategories: [
      {
        id: 'l1-position',
        name: 'L1 Price Position',
        requirement: 'Compares quoted price against tender budget and other bids.',
        method: 'AI-assessed',
        mandatory: true,
        threshold: 'Within budget and commercially viable',
        status: 'Passed',
      },
      {
        id: 'taxes-duties',
        name: 'Taxes and Duties',
        requirement: 'GST, freight, installation, and service charges are clearly included.',
        method: 'Document',
        mandatory: true,
        threshold: 'All taxes and duties declared',
        status: 'Passed',
      },
      {
        id: 'payment-terms',
        name: 'Payment Terms',
        requirement: 'Payment schedule aligns with tender rules and milestone delivery.',
        method: 'AI-assessed',
        mandatory: true,
        threshold: 'No advance beyond allowed clause',
        status: 'Pending',
      },
    ],
  },
  {
    id: 'experience',
    number: 3,
    name: 'Experience Criteria',
    type: 'Document',
    description: 'Prior project experience in similar scope, geography, and operational complexity.',
    subcategories: [
      {
        id: 'similar-projects',
        name: 'Similar Projects',
        requirement: 'Submitted proof of similar completed contracts.',
        method: 'Document',
        mandatory: true,
        threshold: '3 similar projects in last 5 years',
        status: 'Passed',
      },
      {
        id: 'scale-readiness',
        name: 'Scale Readiness',
        requirement: 'Evidence that the bidder can handle requested volume and rollout speed.',
        method: 'AI-assessed',
        mandatory: true,
        threshold: 'At least one project above 50% of tender volume',
        status: 'Flagged',
      },
      {
        id: 'client-certificates',
        name: 'Client Certificates',
        requirement: 'Completion certificates or customer acceptance letters are attached.',
        method: 'Document',
        mandatory: true,
        threshold: 'Certificates for all claimed projects',
        status: 'Passed',
      },
    ],
  },
  {
    id: 'past-performance',
    number: 4,
    name: 'Past Performance',
    type: 'Document',
    description: 'Delivery quality, delay history, penalties, blacklist checks, and customer satisfaction.',
    subcategories: [
      {
        id: 'delay-history',
        name: 'Delay History',
        requirement: 'No unresolved material delays in comparable government contracts.',
        method: 'AI-assessed',
        mandatory: true,
        threshold: 'No major unresolved delay in last 3 years',
        status: 'Passed',
      },
      {
        id: 'penalty-record',
        name: 'Penalty Record',
        requirement: 'Penalty declarations and undertaking are submitted.',
        method: 'Document',
        mandatory: true,
        threshold: 'No active penalty above materiality threshold',
        status: 'Pending',
      },
      {
        id: 'blacklist-check',
        name: 'Blacklist Check',
        requirement: 'Bidder confirms not debarred or blacklisted.',
        method: 'Document',
        mandatory: true,
        threshold: 'Self declaration plus registry check',
        status: 'Passed',
      },
    ],
  },
  {
    id: 'bidder-turnover',
    number: 5,
    name: 'Bidder Turnover',
    type: 'Document',
    description: 'Audited financial capacity and average annual turnover against tender threshold.',
    subcategories: [
      {
        id: 'average-turnover',
        name: 'Average Annual Turnover',
        requirement: 'Audited turnover for three financial years is above tender threshold.',
        method: 'Document',
        mandatory: true,
        threshold: 'Minimum INR 12 Cr average turnover',
        status: 'Passed',
      },
      {
        id: 'net-worth',
        name: 'Positive Net Worth',
        requirement: 'Net worth is positive in latest audited financial statement.',
        method: 'Document',
        mandatory: true,
        threshold: 'Positive net worth in latest FY',
        status: 'Passed',
      },
      {
        id: 'ca-certificate',
        name: 'CA Certificate',
        requirement: 'CA certificate is signed, stamped, and references audited statements.',
        method: 'Document',
        mandatory: true,
        threshold: 'Signed certificate with UDIN',
        status: 'Flagged',
      },
    ],
  },
  {
    id: 'oem-authorization',
    number: 6,
    name: 'OEM Authorization',
    type: 'Document',
    description: 'Manufacturer authorization, product lineage, and support commitment.',
    subcategories: [
      {
        id: 'maf-letter',
        name: 'Manufacturer Authorization Form',
        requirement: 'OEM authorization is tender-specific and signed by an authorized person.',
        method: 'Document',
        mandatory: true,
        threshold: 'Tender-specific MAF required',
        status: 'Flagged',
      },
      {
        id: 'support-commitment',
        name: 'OEM Support Commitment',
        requirement: 'OEM commits spare parts, escalation, and service continuity.',
        method: 'Document',
        mandatory: true,
        threshold: 'Support letter valid through warranty period',
        status: 'Passed',
      },
      {
        id: 'model-authenticity',
        name: 'Model Authenticity',
        requirement: 'Quoted model is active, supported, and matches OEM catalogue.',
        method: 'AI-assessed',
        mandatory: true,
        threshold: 'Active supported model',
        status: 'Passed',
      },
    ],
  },
  {
    id: 'oem-turnover',
    number: 7,
    name: 'OEM Annual Turnover',
    type: 'Document',
    description: 'OEM revenue and financial strength for product continuity and warranty support.',
    subcategories: [
      {
        id: 'oem-average-turnover',
        name: 'OEM Average Turnover',
        requirement: 'OEM annual turnover meets published tender threshold.',
        method: 'Document',
        mandatory: true,
        threshold: 'Minimum INR 50 Cr average turnover',
        status: 'Passed',
      },
      {
        id: 'oem-audited-statements',
        name: 'OEM Audited Statements',
        requirement: 'Audited statements or annual report are attached.',
        method: 'Document',
        mandatory: true,
        threshold: 'Latest 3 financial years',
        status: 'Pending',
      },
      {
        id: 'oem-country-presence',
        name: 'Local Service Presence',
        requirement: 'OEM has authorized service capacity in India.',
        method: 'AI-assessed',
        mandatory: false,
        threshold: 'Service location within 250 km',
        status: 'Passed',
      },
    ],
  },
  {
    id: 'atc-certificate',
    number: 8,
    name: 'Certificate (ATC)',
    type: 'Document',
    description: 'Additional terms and conditions, statutory certificates, declarations, and affidavits.',
    subcategories: [
      {
        id: 'atc-acceptance',
        name: 'ATC Acceptance',
        requirement: 'Bidder accepts all additional terms without deviation.',
        method: 'Document',
        mandatory: true,
        threshold: 'Signed acceptance required',
        status: 'Passed',
      },
      {
        id: 'statutory-declarations',
        name: 'Statutory Declarations',
        requirement: 'Declarations for debarment, conflict of interest, and local content are attached.',
        method: 'Document',
        mandatory: true,
        threshold: 'All declarations attached',
        status: 'Passed',
      },
      {
        id: 'local-content',
        name: 'Local Content Certificate',
        requirement: 'Local content declaration complies with procurement preference clause.',
        method: 'AI-assessed',
        mandatory: false,
        threshold: 'Class-I or Class-II supplier proof',
        status: 'Pending',
      },
    ],
  },
  {
    id: 'boq',
    number: 9,
    name: 'BoQ Compliance',
    type: 'Document',
    description: 'Bill of quantities, line item mapping, quantity match, and commercial completeness.',
    subcategories: [
      {
        id: 'line-items',
        name: 'Line Item Match',
        requirement: 'All BoQ line items are present and mapped to quoted products.',
        method: 'AI-assessed',
        mandatory: true,
        threshold: '100% mandatory line item coverage',
        status: 'Passed',
      },
      {
        id: 'quantity-match',
        name: 'Quantity Match',
        requirement: 'Quantities match tender requirement without hidden exclusions.',
        method: 'Document',
        mandatory: true,
        threshold: 'No quantity deviation',
        status: 'Passed',
      },
      {
        id: 'commercial-annexure',
        name: 'Commercial Annexure',
        requirement: 'Commercial annexure is signed and totals reconcile with quoted value.',
        method: 'Document',
        mandatory: true,
        threshold: 'Totals reconcile within INR 1',
        status: 'Flagged',
      },
    ],
  },
];

const baseEvidence = {
  technical: {
    extractedValue: 'Specification sheet and implementation plan parsed',
    explanation: 'Core technical requirements are covered, with a few items requiring officer review.',
    documentRef: 'TECH-SPEC.pdf p. 4-12',
  },
  financial: {
    extractedValue: 'Commercial quote within approved budget envelope',
    explanation: 'Quoted amount is commercially acceptable and all major tax heads were declared.',
    documentRef: 'PRICE-BID.xlsx sheet 1',
  },
  experience: {
    extractedValue: 'Three similar public sector rollouts declared',
    explanation: 'Experience documents are strong, but one project certificate needs date validation.',
    documentRef: 'PAST-WORK.pdf p. 2-8',
  },
  'past-performance': {
    extractedValue: 'No active debarment declaration found',
    explanation: 'Performance undertaking is attached and no severe penalty declaration was detected.',
    documentRef: 'UNDERTAKING.pdf p. 1',
  },
  'bidder-turnover': {
    extractedValue: 'Average turnover above tender threshold',
    explanation: 'Audited values exceed the minimum threshold. CA certificate metadata needs review for one bidder.',
    documentRef: 'FINANCIALS.pdf p. 5',
  },
  'oem-authorization': {
    extractedValue: 'OEM authorization attached',
    explanation: 'Authorization letter is present. Signature authority and tender-specific wording were checked.',
    documentRef: 'OEM-MAF.pdf p. 1',
  },
  'oem-turnover': {
    extractedValue: 'OEM financials attached',
    explanation: 'OEM turnover evidence is present, though latest-year statements are clearer for some bids than others.',
    documentRef: 'OEM-FIN.pdf p. 3',
  },
  'atc-certificate': {
    extractedValue: 'ATC acceptance and statutory declarations attached',
    explanation: 'Required declarations were detected and mapped to the relevant tender clauses.',
    documentRef: 'ATC-AFFIDAVIT.pdf p. 1-4',
  },
  boq: {
    extractedValue: 'BoQ lines mapped to quoted models',
    explanation: 'Mandatory BoQ lines are covered. Commercial annexure totals should be reviewed where flagged.',
    documentRef: 'BOQ.xlsx sheet 2',
  },
};

export function buildEvaluations(overrides = {}) {
  return evaluationCategories.map((category) => {
    const override = overrides[category.id] || {};
    const status = override.status || 'Eligible';
    const confidence = override.confidence || (status === 'Eligible' ? 91 : status === 'Needs Review' ? 68 : 42);
    return {
      criterionId: category.id,
      criterionName: category.name,
      status,
      confidence,
      extractedValue: override.extractedValue || baseEvidence[category.id].extractedValue,
      explanation: override.explanation || baseEvidence[category.id].explanation,
      documentRef: override.documentRef || baseEvidence[category.id].documentRef,
      subChecks: category.subcategories.map((sub, index) => ({
        id: sub.id,
        name: sub.name,
        status: override.subChecks?.[sub.id] || (status === 'Not Eligible' && index === 0 ? 'Failed' : sub.status),
        evidence: sub.threshold,
      })),
    };
  });
}

function cloneData(value) {
  return JSON.parse(JSON.stringify(value));
}

export const demoTenders = [
  {
    id: 'TDR-001',
    gemId: 'GEM/2026/B/6129043',
    title: 'Rugged tablet kits for field inspection teams',
    department: 'State Disaster Response and Field Operations',
    location: 'Maharashtra',
    category: 'IT Hardware',
    subcategory: 'Rugged Mobility',
    budget: 'INR 4.8 Cr',
    budgetValue: 4.8,
    deadline: '2026-05-12',
    status: 'Bid Evaluation',
    priorityLevel: 'Critical',
    priorityScore: 94,
    description: 'Supply, configuration, training, and warranty support for rugged Android tablet kits with field accessories.',
    criteriaLocked: true,
    bids: [
      {
        id: 'BID-RT-001',
        bidderName: 'Astra Mobility Systems Pvt Ltd',
        bidderType: 'MSME',
        location: 'Pune',
        quote: 'INR 4.52 Cr',
        quoteValue: 4.52,
        submittedAt: '2026-04-29 18:42',
        status: 'Needs Review',
        priorityScore: 96,
        score: 86,
        decision: 'Under Review',
        priorityReason: 'Lowest quote, strong technical fit, but OEM letter needs officer validation.',
        companyProfile: 'Rugged mobile device integrator with police, municipal, and disaster-response deployments.',
        strengths: ['L1 commercial quote', 'MIL-STD protection claimed', 'Local service team in Pune'],
        riskFlags: ['OEM authorization signature is scanned', 'Battery lifecycle claim needs source validation'],
        documents: [
          { id: 'doc-rt-1', name: 'Technical Compliance Matrix', type: 'PDF', confidence: 93, summary: 'All mandatory device specifications mapped.' },
          { id: 'doc-rt-2', name: 'OEM Authorization Letter', type: 'Scanned', confidence: 61, summary: 'Letter present, signature authority needs review.' },
          { id: 'doc-rt-3', name: 'Commercial BoQ', type: 'Spreadsheet', confidence: 88, summary: 'Totals reconcile with quoted value.' },
          { id: 'doc-rt-4', name: 'Past Project Certificates', type: 'PDF', confidence: 81, summary: 'Three similar deployments attached.' },
        ],
        evaluations: buildEvaluations({
          'oem-authorization': {
            status: 'Needs Review',
            confidence: 61,
            extractedValue: 'OEM authorization present but scanned signature is unclear',
            explanation: 'GPT detected the MAF but could not verify signature authority from the scan.',
            documentRef: 'OEM-MAF.pdf p. 1',
            subChecks: { 'maf-letter': 'Flagged' },
          },
          'bidder-turnover': {
            status: 'Needs Review',
            confidence: 72,
            extractedValue: 'Average turnover exceeds threshold; UDIN not machine readable',
            documentRef: 'FINANCIALS.pdf p. 4',
            subChecks: { 'ca-certificate': 'Flagged' },
          },
        }),
      },
      {
        id: 'BID-RT-002',
        bidderName: 'Nexus FieldTech Solutions',
        bidderType: 'Large Enterprise',
        location: 'Bengaluru',
        quote: 'INR 4.74 Cr',
        quoteValue: 4.74,
        submittedAt: '2026-04-30 09:11',
        status: 'Evaluated',
        priorityScore: 84,
        score: 91,
        decision: 'Shortlisted',
        priorityReason: 'Higher price, but clean documents and strong support commitments.',
        companyProfile: 'Enterprise mobility supplier focused on rugged devices, MDM, and logistics support.',
        strengths: ['Clean OEM authorization', 'Strong support SLA', 'Complete BoQ mapping'],
        riskFlags: ['Commercial quote close to budget ceiling'],
        documents: [
          { id: 'doc-rt-5', name: 'Technical Dossier', type: 'PDF', confidence: 95, summary: 'Complete technical dossier with test certificates.' },
          { id: 'doc-rt-6', name: 'OEM MAF', type: 'PDF', confidence: 92, summary: 'Tender-specific MAF verified.' },
          { id: 'doc-rt-7', name: 'Commercial Bid', type: 'Spreadsheet', confidence: 89, summary: 'Commercial totals and taxes clear.' },
        ],
        evaluations: buildEvaluations(),
      },
    ],
  },
  {
    id: 'TDR-002',
    gemId: 'GEM/2026/B/6190188',
    title: 'AI video analytics for perimeter security',
    department: 'Regional Airport Security Directorate',
    location: 'Karnataka',
    category: 'Security Technology',
    subcategory: 'Video Analytics',
    budget: 'INR 8.2 Cr',
    budgetValue: 8.2,
    deadline: '2026-05-18',
    status: 'Technical Evaluation',
    priorityLevel: 'High',
    priorityScore: 88,
    description: 'Deploy edge AI video analytics, intrusion detection, camera integration, and operator dashboards.',
    criteriaLocked: true,
    bids: [
      {
        id: 'BID-VA-001',
        bidderName: 'Sentinel Vision Analytics',
        bidderType: 'Startup',
        location: 'Hyderabad',
        quote: 'INR 7.65 Cr',
        quoteValue: 7.65,
        submittedAt: '2026-05-01 11:24',
        status: 'Needs Review',
        priorityScore: 91,
        score: 82,
        decision: 'Under Review',
        priorityReason: 'Strong AI score with missing cyber hardening annexure.',
        companyProfile: 'Computer vision startup with smart-city surveillance deployments and airport pilot references.',
        strengths: ['High detection accuracy claim', 'Edge inference architecture', 'Fast pilot timeline'],
        riskFlags: ['Cyber hardening checklist incomplete', 'False alarm test evidence ambiguous'],
        documents: [
          { id: 'doc-va-1', name: 'AI Model Performance Report', type: 'PDF', confidence: 78, summary: 'Accuracy claims extracted with medium confidence.' },
          { id: 'doc-va-2', name: 'Cybersecurity Annexure', type: 'PDF', confidence: 49, summary: 'Hardening section incomplete.' },
          { id: 'doc-va-3', name: 'BoQ Integration Sheet', type: 'Spreadsheet', confidence: 86, summary: 'Camera integration quantities mapped.' },
        ],
        evaluations: buildEvaluations({
          technical: {
            status: 'Needs Review',
            confidence: 70,
            extractedValue: 'Analytics specification mostly compliant; false alarm evidence unclear',
            documentRef: 'AI-PERFORMANCE.pdf p. 6',
            subChecks: { 'implementation-plan': 'Flagged' },
          },
          boq: {
            status: 'Eligible',
            confidence: 88,
          },
          'atc-certificate': {
            status: 'Needs Review',
            confidence: 58,
            extractedValue: 'Cybersecurity hardening annexure is incomplete',
            documentRef: 'CYBER-ANNEXURE.pdf p. 3',
            subChecks: { 'statutory-declarations': 'Pending' },
          },
        }),
      },
      {
        id: 'BID-VA-002',
        bidderName: 'SecureGrid Technologies',
        bidderType: 'Large Enterprise',
        location: 'Noida',
        quote: 'INR 8.05 Cr',
        quoteValue: 8.05,
        submittedAt: '2026-05-01 15:20',
        status: 'Evaluated',
        priorityScore: 79,
        score: 88,
        decision: 'Shortlisted',
        priorityReason: 'Clean compliance and proven airport deployment references.',
        companyProfile: 'Security system integrator with control-room, access control, and surveillance analytics programs.',
        strengths: ['Complete cyber annexure', 'Airport references', 'Strong OEM documentation'],
        riskFlags: ['Near budget ceiling'],
        documents: [
          { id: 'doc-va-4', name: 'Technical Architecture', type: 'PDF', confidence: 90, summary: 'Architecture and edge appliance mapping complete.' },
          { id: 'doc-va-5', name: 'Past Performance Pack', type: 'PDF', confidence: 87, summary: 'Airport and metro projects attached.' },
          { id: 'doc-va-6', name: 'Financial Bid', type: 'Spreadsheet', confidence: 91, summary: 'Tax and installation cost declared.' },
        ],
        evaluations: buildEvaluations(),
      },
    ],
  },
  {
    id: 'TDR-003',
    gemId: 'GEM/2026/B/6214570',
    title: 'Solar microgrid and battery storage for rural hospitals',
    department: 'Public Health Infrastructure Mission',
    location: 'Rajasthan',
    category: 'Energy Infrastructure',
    subcategory: 'Solar and BESS',
    budget: 'INR 12.6 Cr',
    budgetValue: 12.6,
    deadline: '2026-05-24',
    status: 'Commercial Review',
    priorityLevel: 'Medium',
    priorityScore: 73,
    description: 'Design, supply, installation, commissioning, and five-year O&M for hospital microgrid systems.',
    criteriaLocked: false,
    bids: [
      {
        id: 'BID-SG-001',
        bidderName: 'SunGrid Energy Systems',
        bidderType: 'Large Enterprise',
        location: 'Jaipur',
        quote: 'INR 11.88 Cr',
        quoteValue: 11.88,
        submittedAt: '2026-05-02 10:05',
        status: 'Pending',
        priorityScore: 76,
        score: 78,
        decision: 'Under Review',
        priorityReason: 'Strong price but battery warranty language is not aligned to tender clause.',
        companyProfile: 'Solar EPC firm with public health and rural electrification installations.',
        strengths: ['Competitive commercial bid', 'Local O&M team', 'Hospital references'],
        riskFlags: ['Battery warranty clause deviation', 'OEM turnover statement missing latest year'],
        documents: [
          { id: 'doc-sg-1', name: 'Solar EPC Method Statement', type: 'PDF', confidence: 83, summary: 'Deployment method and safety plan extracted.' },
          { id: 'doc-sg-2', name: 'Battery Warranty Letter', type: 'Scanned', confidence: 54, summary: 'Warranty years visible, degradation clause unclear.' },
          { id: 'doc-sg-3', name: 'Commercial Annexure', type: 'Spreadsheet', confidence: 80, summary: 'BoQ totals match quote.' },
        ],
        evaluations: buildEvaluations({
          technical: {
            status: 'Needs Review',
            confidence: 63,
            extractedValue: 'Battery warranty degradation clause requires manual review',
            documentRef: 'BATTERY-WARRANTY.pdf p. 2',
          },
          'oem-turnover': {
            status: 'Needs Review',
            confidence: 59,
            extractedValue: 'Latest OEM statement not found',
            documentRef: 'OEM-FIN.pdf p. 1-2',
            subChecks: { 'oem-audited-statements': 'Pending' },
          },
        }),
      },
    ],
  },
  {
    id: 'TDR-004',
    gemId: 'GEM/2026/B/6250331',
    title: 'Managed detection and response SOC services',
    department: 'State Data Centre Authority',
    location: 'Tamil Nadu',
    category: 'Cybersecurity',
    subcategory: 'Managed SOC',
    budget: 'INR 6.4 Cr',
    budgetValue: 6.4,
    deadline: '2026-06-02',
    status: 'Criteria Extraction',
    priorityLevel: 'Low',
    priorityScore: 58,
    description: 'Three-year managed SOC with SIEM integration, threat hunting, incident response, and reporting.',
    criteriaLocked: false,
    bids: [
      {
        id: 'BID-SOC-001',
        bidderName: 'RedShield Cyber Defense',
        bidderType: 'MSME',
        location: 'Chennai',
        quote: 'INR 5.92 Cr',
        quoteValue: 5.92,
        submittedAt: '2026-05-02 16:38',
        status: 'Pending',
        priorityScore: 64,
        score: 74,
        decision: 'Under Review',
        priorityReason: 'Attractive commercial bid, but SOC staffing certificates are pending review.',
        companyProfile: 'Cybersecurity services firm focused on MDR, SIEM tuning, and incident response retainers.',
        strengths: ['Cost advantage', 'Threat-hunting methodology included', 'Local service desk'],
        riskFlags: ['Analyst certification mapping incomplete', 'Past performance references are smaller scale'],
        documents: [
          { id: 'doc-soc-1', name: 'SOC Operations Plan', type: 'PDF', confidence: 84, summary: 'Shift plan and escalation workflow extracted.' },
          { id: 'doc-soc-2', name: 'Analyst Certification Pack', type: 'PDF', confidence: 57, summary: 'Certifications present but role mapping unclear.' },
          { id: 'doc-soc-3', name: 'Financial Bid', type: 'Spreadsheet', confidence: 87, summary: 'Quote and tax details extracted.' },
        ],
        evaluations: buildEvaluations({
          experience: {
            status: 'Needs Review',
            confidence: 62,
            extractedValue: 'Past SOC references are below requested user count',
            documentRef: 'PAST-WORK.pdf p. 4',
            subChecks: { 'scale-readiness': 'Flagged' },
          },
        }),
      },
    ],
  },
];

const sampleTenderUploads = [
  {
    fileName: 'TenderLens-Airport-Video-Analytics-Sample.pdf',
    tenderId: 'TDR-UP-001',
    title: 'Airport perimeter AI video analytics and incident response platform',
    subtitle: 'Regional airport security tender pack with scope, eligibility, cybersecurity annexure, and BoQ.',
    downloadHref: '/TenderLens-Airport-Video-Analytics-Sample.pdf',
    previewDocuments: [
      'Tender Notice and Submission Schedule',
      'Technical Scope and Detection Matrix',
      'Cybersecurity Hardening Annexure',
      'Commercial BoQ and Price Schedule',
      'OEM Support Commitment',
      'Past Performance and Eligibility Forms',
    ],
    criteriaHighlights: [
      {
        id: 'scope-detection',
        title: 'AI detection and response',
        clause: 'Section 4.2',
        detail: 'The platform must deliver intrusion, loitering, and perimeter breach alerts with less than 3 second response latency.',
      },
      {
        id: 'cyber-hardening',
        title: 'Cybersecurity controls',
        clause: 'Annexure C',
        detail: 'Bidders must include hardening checklists, audit logging, role-based access, and secure remote support controls.',
      },
      {
        id: 'experience-proof',
        title: 'Critical infrastructure references',
        clause: 'Section 6.1',
        detail: 'At least three completed airport, metro, or other critical infrastructure deployments in the last five years are required.',
      },
      {
        id: 'support-window',
        title: 'Warranty and support SLA',
        clause: 'Section 7.4',
        detail: 'The tender mandates a 36 month warranty, 24x7 command-center support, and next-business-day hardware replacement.',
      },
    ],
    categoryOverrides: {
      technical: {
        description: 'AI detection accuracy, incident workflow, VMS integration, and deployment readiness extracted from the airport security scope.',
        subcategories: {
          'spec-match': {
            requirement: 'Matches mandatory AI analytics, VMS integration, retention, and alerting specifications.',
            threshold: '95% detection benchmark with alert latency below 3 seconds',
            status: 'Passed',
          },
          'implementation-plan': {
            requirement: 'Provides deployment plan, test scripts, operator training, and phased cutover for airport operations.',
            threshold: 'Named rollout milestones for pilot, integration, and acceptance testing',
            status: 'Pending',
          },
          'warranty-support': {
            requirement: 'Meets warranty period, spare coverage, and 24x7 support workflow requirements.',
            threshold: '36 month warranty and next-business-day hardware replacement',
            status: 'Passed',
          },
        },
      },
      financial: {
        description: 'Commercial competitiveness, tax completeness, and payment terms parsed from the price schedule.',
        subcategories: {
          'l1-position': {
            threshold: 'Commercial bid must remain within INR 9.40 Cr approved estimate',
            status: 'Passed',
          },
          'taxes-duties': {
            threshold: 'GST, installation, commissioning, and training charges explicitly declared',
            status: 'Passed',
          },
          'payment-terms': {
            threshold: 'No mobilization advance beyond airport procurement clause 8.3',
            status: 'Pending',
          },
        },
      },
      experience: {
        description: 'Deployment references, commissioning scale, and completion certificates extracted from the eligibility pack.',
        subcategories: {
          'similar-projects': {
            threshold: 'Three completed airport or critical infrastructure programs in the last five years',
            status: 'Passed',
          },
          'scale-readiness': {
            threshold: 'At least one prior deployment covering 200 or more cameras',
            status: 'Flagged',
          },
          'client-certificates': {
            threshold: 'Completion certificates or customer sign-off for every claimed deployment',
            status: 'Passed',
          },
        },
      },
      'past-performance': {
        description: 'Delay history, penalty declarations, and debarment checks aligned to the airport tender.',
        subcategories: {
          'delay-history': {
            threshold: 'No unresolved delay in airport or critical infrastructure contracts during the last 3 years',
            status: 'Passed',
          },
          'penalty-record': {
            threshold: 'No active penalty above the tender materiality threshold',
            status: 'Pending',
          },
          'blacklist-check': {
            threshold: 'No active debarment declaration and registry confirmation',
            status: 'Passed',
          },
        },
      },
      'bidder-turnover': {
        description: 'Bidder financial capacity extracted from audited statements and CA certificate.',
        subcategories: {
          'average-turnover': {
            threshold: 'Minimum INR 18 Cr average turnover over the last 3 financial years',
            status: 'Passed',
          },
          'net-worth': {
            threshold: 'Positive net worth in latest audited statement',
            status: 'Passed',
          },
          'ca-certificate': {
            threshold: 'Signed CA certificate with UDIN tied to audited statements',
            status: 'Flagged',
          },
        },
      },
      'oem-authorization': {
        description: 'Manufacturer authorization and long-term support commitment for cameras, servers, and analytics appliances.',
        subcategories: {
          'maf-letter': {
            threshold: 'Tender-specific OEM authorization signed by country manager or equivalent',
            status: 'Flagged',
          },
          'support-commitment': {
            threshold: 'OEM support letter valid through warranty and ATS period',
            status: 'Passed',
          },
          'model-authenticity': {
            threshold: 'Quoted analytics appliance and camera models must be active and supported',
            status: 'Passed',
          },
        },
      },
      'oem-turnover': {
        description: 'OEM financial capacity and India service presence extracted from annual reports and declarations.',
        subcategories: {
          'oem-average-turnover': {
            threshold: 'Minimum INR 75 Cr OEM average annual turnover',
            status: 'Passed',
          },
          'oem-audited-statements': {
            threshold: 'Latest 3 years of OEM audited statements attached',
            status: 'Pending',
          },
          'oem-country-presence': {
            threshold: 'Authorized India support and spare stocking capability',
            status: 'Passed',
          },
        },
      },
      'atc-certificate': {
        description: 'Airport-specific declarations, cybersecurity affidavits, and local-content statements.',
        subcategories: {
          'atc-acceptance': {
            threshold: 'Signed acceptance of all airport-specific additional terms',
            status: 'Passed',
          },
          'statutory-declarations': {
            threshold: 'Cyber hardening, conflict, local-content, and integrity declarations submitted',
            status: 'Flagged',
          },
          'local-content': {
            threshold: 'Local-content certificate aligned to procurement preference clause',
            status: 'Pending',
          },
        },
      },
      boq: {
        description: 'BoQ line mapping, quantity reconciliation, and commercial completeness parsed from the price schedule.',
        subcategories: {
          'line-items': {
            threshold: '100% mapping of mandatory camera, server, storage, and software line items',
            status: 'Passed',
          },
          'quantity-match': {
            threshold: 'No quantity variance against the issued BoQ',
            status: 'Passed',
          },
          'commercial-annexure': {
            threshold: 'Commercial annexure totals reconcile with price bid and taxes',
            status: 'Flagged',
          },
        },
      },
    },
    tenderTemplate: {
      id: 'TDR-UP-001',
      gemId: 'GEM/2026/B/6312405',
      title: 'Airport perimeter AI video analytics and incident response platform',
      department: 'Airport Operations and Security Modernisation Unit',
      location: 'Karnataka',
      category: 'Security Technology',
      subcategory: 'Video Analytics',
      budget: 'INR 9.4 Cr',
      budgetValue: 9.4,
      deadline: '2026-06-11',
      status: 'Criteria Extracted',
      priorityLevel: 'High',
      priorityScore: 89,
      description: 'Design, supply, integration, testing, commissioning, and support for AI-driven perimeter analytics across an operational regional airport.',
      criteriaLocked: false,
      extractionSummary: {
        sourceFileName: 'TenderLens-Airport-Video-Analytics-Sample.pdf',
        previewDocuments: [
          'Tender Notice and Submission Schedule',
          'Technical Scope and Detection Matrix',
          'Cybersecurity Hardening Annexure',
          'Commercial BoQ and Price Schedule',
          'OEM Support Commitment',
          'Past Performance and Eligibility Forms',
        ],
        criteriaHighlights: [
          {
            id: 'scope-detection',
            title: 'AI detection and response',
            clause: 'Section 4.2',
            detail: 'The platform must deliver intrusion, loitering, and perimeter breach alerts with less than 3 second response latency.',
          },
          {
            id: 'cyber-hardening',
            title: 'Cybersecurity controls',
            clause: 'Annexure C',
            detail: 'Bidders must include hardening checklists, audit logging, role-based access, and secure remote support controls.',
          },
          {
            id: 'experience-proof',
            title: 'Critical infrastructure references',
            clause: 'Section 6.1',
            detail: 'At least three completed airport, metro, or other critical infrastructure deployments in the last five years are required.',
          },
          {
            id: 'support-window',
            title: 'Warranty and support SLA',
            clause: 'Section 7.4',
            detail: 'The tender mandates a 36 month warranty, 24x7 command-center support, and next-business-day hardware replacement.',
          },
        ],
      },
      bids: [
        {
          id: 'BID-AP-001',
          bidderName: 'AeroSentinel Systems Private Limited',
          bidderType: 'Large Enterprise',
          location: 'Bengaluru',
          quote: 'INR 8.74 Cr',
          quoteValue: 8.74,
          submittedAt: '2026-05-06 16:15',
          status: 'Needs Review',
          priorityScore: 93,
          score: 84,
          decision: 'Under Review',
          priorityReason: 'Strong commercial position and mature airport references, but the cyber hardening addendum still needs officer validation.',
          companyProfile: 'Airport surveillance and command-centre systems integrator with AI analytics, VMS, and secure operations rollouts.',
          strengths: ['Competitive quote', 'Strong airport references', 'Detailed VMS integration plan'],
          riskFlags: ['Cyber hardening checklist lacks segregation diagram', 'OEM escalation matrix signature needs review'],
          documents: [
            { id: 'doc-ap-1', name: 'Technical Scope Response', type: 'PDF', confidence: 91, summary: 'Camera, server, and analytics specifications mapped to the tender matrix.' },
            { id: 'doc-ap-2', name: 'Cybersecurity Hardening Annexure', type: 'PDF', confidence: 64, summary: 'Most controls are present; network segregation evidence is incomplete.' },
            { id: 'doc-ap-3', name: 'Commercial BoQ and Pricing', type: 'Spreadsheet', confidence: 89, summary: 'Commercial schedule reconciles with quoted value and tax heads.' },
            { id: 'doc-ap-4', name: 'Airport Deployment Certificates', type: 'PDF', confidence: 84, summary: 'Critical infrastructure references and acceptance certificates are attached.' },
          ],
          evaluations: buildEvaluations({
            technical: {
              status: 'Needs Review',
              confidence: 74,
              extractedValue: 'Detection and integration scope is strong, but false-alarm test evidence needs manual review.',
              explanation: 'GPT matched the analytics stack and VMS integration plan, but the airport pilot validation matrix is incomplete.',
              documentRef: 'TECHNICAL-SCOPE.pdf p. 8-12',
              subChecks: { 'implementation-plan': 'Flagged' },
            },
            'oem-authorization': {
              status: 'Needs Review',
              confidence: 66,
              extractedValue: 'OEM support commitment is present, but the signatory authority is not fully established.',
              explanation: 'The support letter exists, though the signature block does not clearly map to the OEM country lead.',
              documentRef: 'OEM-SUPPORT.pdf p. 1',
              subChecks: { 'maf-letter': 'Flagged' },
            },
            'atc-certificate': {
              status: 'Needs Review',
              confidence: 62,
              extractedValue: 'Cybersecurity hardening checklist is attached with one missing network zoning annexure.',
              explanation: 'The airport cyber annexure covers logging and RBAC, but the segmentation diagram is referenced, not attached.',
              documentRef: 'CYBER-ANNEXURE.pdf p. 3-5',
              subChecks: { 'statutory-declarations': 'Pending' },
            },
          }),
        },
        {
          id: 'BID-AP-002',
          bidderName: 'SkyGrid Secure Infrastructure Limited',
          bidderType: 'Large Enterprise',
          location: 'Noida',
          quote: 'INR 9.02 Cr',
          quoteValue: 9.02,
          submittedAt: '2026-05-06 17:02',
          status: 'Evaluated',
          priorityScore: 85,
          score: 90,
          decision: 'Shortlisted',
          priorityReason: 'Documentation is exceptionally clean and airport deployment maturity is strong, though the commercial bid is close to the ceiling.',
          companyProfile: 'National critical-infrastructure integrator with airport surveillance, SOC, and control-room modernization programs.',
          strengths: ['Complete compliance set', 'Airport command-centre references', 'Clean OEM backing'],
          riskFlags: ['Commercial bid close to budget ceiling'],
          documents: [
            { id: 'doc-ap-5', name: 'Integrated Technical Proposal', type: 'PDF', confidence: 94, summary: 'End-to-end architecture, retention, analytics, and dashboard scope are fully documented.' },
            { id: 'doc-ap-6', name: 'OEM Authorization and Support Letter', type: 'PDF', confidence: 93, summary: 'Tender-specific OEM authorization and spare support commitment verified.' },
            { id: 'doc-ap-7', name: 'Price Bid and Commercial Annexure', type: 'Spreadsheet', confidence: 92, summary: 'Commercial totals, taxes, and implementation costs reconcile cleanly.' },
            { id: 'doc-ap-8', name: 'Airport Performance Dossier', type: 'PDF', confidence: 88, summary: 'Completed airport and metro security projects supported with certificates.' },
          ],
          evaluations: buildEvaluations(),
        },
        {
          id: 'BID-AP-003',
          bidderName: 'Vigilant Edge AI Consortium',
          bidderType: 'Consortium',
          location: 'Hyderabad',
          quote: 'INR 8.61 Cr',
          quoteValue: 8.61,
          submittedAt: '2026-05-06 18:19',
          status: 'Pending',
          priorityScore: 88,
          score: 79,
          decision: 'Under Review',
          priorityReason: 'The commercial bid is attractive, but consortium financial and experience evidence still needs deeper verification.',
          companyProfile: 'Analytics, networking, and field-operations consortium formed for critical surveillance and edge-AI programs.',
          strengths: ['Lowest blended price among compliant bids', 'Edge analytics stack', 'Strong incident workflow proposal'],
          riskFlags: ['Consortium turnover affidavit pending', 'Two performance certificates lack commissioning dates'],
          documents: [
            { id: 'doc-ap-9', name: 'Consortium Technical Response', type: 'PDF', confidence: 82, summary: 'Technical response is broad, though supporting validation is uneven across annexures.' },
            { id: 'doc-ap-10', name: 'Financial Capacity Pack', type: 'PDF', confidence: 69, summary: 'Financial statements are attached, but one consortium member affidavit is pending.' },
            { id: 'doc-ap-11', name: 'Commercial Price Workbook', type: 'Spreadsheet', confidence: 87, summary: 'Line-item pricing is competitive and mostly reconciled.' },
            { id: 'doc-ap-12', name: 'Performance Certificates', type: 'PDF', confidence: 71, summary: 'Reference projects exist, but commissioning dates are missing from two certificates.' },
          ],
          evaluations: buildEvaluations({
            experience: {
              status: 'Needs Review',
              confidence: 65,
              extractedValue: 'Critical infrastructure references are relevant, but two completion certificates need date validation.',
              explanation: 'The consortium shows security rollouts of similar scale, though evidence quality is mixed across member entities.',
              documentRef: 'PERFORMANCE-CERTIFICATES.pdf p. 2-6',
              subChecks: { 'scale-readiness': 'Flagged' },
            },
            'bidder-turnover': {
              status: 'Needs Review',
              confidence: 61,
              extractedValue: 'Lead member financials are clear; one consortium partner affidavit is still pending.',
              explanation: 'Turnover is likely above threshold, but the missing affidavit prevents a clean machine-verifiable pass.',
              documentRef: 'FINANCIAL-CAPACITY.pdf p. 7',
              subChecks: { 'ca-certificate': 'Flagged' },
            },
          }),
        },
      ],
    },
  },
];

export const featuredSampleTender = sampleTenderUploads[0];

export const auditTrailSeed = [
  {
    id: 'LOG-001',
    timestamp: '2026-05-03T09:12:00.000Z',
    actionType: 'Evaluation',
    actor: 'GPT Engine',
    description: 'Generated 9-category evaluation for BID-RT-001 and flagged OEM authorization for manual review.',
    tenderId: 'TDR-001',
    bidId: 'BID-RT-001',
    hash: '0x9b17a24f',
  },
  {
    id: 'LOG-002',
    timestamp: '2026-05-03T08:44:00.000Z',
    actionType: 'Criteria',
    actor: 'Procurement Officer',
    description: 'Locked extracted criteria for rugged tablet tender after threshold review.',
    tenderId: 'TDR-001',
    hash: '0xc4a80311',
  },
  {
    id: 'LOG-003',
    timestamp: '2026-05-02T18:28:00.000Z',
    actionType: 'Upload',
    actor: 'System',
    description: 'Parsed tender document and extracted technical, commercial, and statutory criteria.',
    tenderId: 'TDR-002',
    hash: '0x4e288d0b',
  },
];

export function getAllBids(tenders) {
  return tenders.flatMap((tender) =>
    tender.bids.map((bid) => ({
      ...bid,
      tenderId: tender.id,
      tenderTitle: tender.title,
      gemId: tender.gemId,
      deadline: tender.deadline,
      department: tender.department,
      category: tender.category,
      subcategory: tender.subcategory,
      budget: tender.budget,
      tenderStatus: tender.status,
    })),
  );
}

export function getOverallStatus(evaluations) {
  if (evaluations.some((item) => item.status === 'Not Eligible')) return 'Not Eligible';
  if (evaluations.some((item) => item.status === 'Needs Review')) return 'Needs Manual Review';
  return 'Eligible';
}

export function getSampleTenderByFileName(fileName) {
  const normalizedFileName = fileName?.trim().toLowerCase();
  if (!normalizedFileName) return null;
  return sampleTenderUploads.find((item) => item.fileName.toLowerCase() === normalizedFileName) || null;
}

export function createCategoriesFromUpload(fileName) {
  const sample = getSampleTenderByFileName(fileName);
  const categories = cloneData(evaluationCategories);

  if (!sample) {
    return categories;
  }

  return categories.map((category) => {
    const override = sample.categoryOverrides?.[category.id];
    if (!override) return category;

    return {
      ...category,
      description: override.description || category.description,
      type: override.type || category.type,
      subcategories: category.subcategories.map((subcategory) => {
        const subOverride = override.subcategories?.[subcategory.id];
        return subOverride ? { ...subcategory, ...subOverride } : subcategory;
      }),
    };
  });
}

export function createTenderFromUpload(fileName) {
  const sample = getSampleTenderByFileName(fileName);
  return sample ? cloneData(sample.tenderTemplate) : null;
}

export function createDemoBid(tender, index) {
  const suffix = String(index + 1).padStart(3, '0');
  return {
    id: `BID-DEMO-${suffix}`,
    bidderName: `Demo Consortium ${index + 1}`,
    bidderType: 'Consortium',
    location: tender.location,
    quote: `INR ${(Math.max(tender.budgetValue - 0.34, 1)).toFixed(2)} Cr`,
    quoteValue: Math.max(tender.budgetValue - 0.34, 1),
    submittedAt: new Date().toISOString().slice(0, 16).replace('T', ' '),
    status: 'Pending',
    priorityScore: Math.min(tender.priorityScore + 2, 99),
    score: 72,
    decision: 'Under Review',
    priorityReason: 'New demo bid added for the judging walkthrough.',
    companyProfile: 'Demo bidder generated inside the prototype to prove the workflow handles new submissions.',
    strengths: ['Complete submission shell', 'Competitive quote', 'Ready for GPT-style review'],
    riskFlags: ['Requires officer review before shortlist'],
    documents: [
      { id: `doc-demo-${suffix}-1`, name: 'Technical Proposal', type: 'PDF', confidence: 76, summary: 'Demo technical proposal loaded.' },
      { id: `doc-demo-${suffix}-2`, name: 'Commercial BoQ', type: 'Spreadsheet', confidence: 81, summary: 'Demo BoQ totals parsed.' },
      { id: `doc-demo-${suffix}-3`, name: 'Statutory Declarations', type: 'PDF', confidence: 74, summary: 'Demo declarations attached.' },
    ],
    evaluations: buildEvaluations({
      experience: {
        status: 'Needs Review',
        confidence: 63,
        extractedValue: 'Demo experience evidence requires officer validation',
      },
    }),
  };
}
