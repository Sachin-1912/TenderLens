const CATEGORY_LABELS = {
  technical: 'Technical',
  financial: 'Financial',
  experience: 'Experience',
  'past-performance': 'Past Perf.',
  'bidder-turnover': 'Bidder Fin.',
  'oem-authorization': 'OEM Auth.',
  'oem-turnover': 'OEM Fin.',
  'atc-certificate': 'ATC',
  boq: 'BoQ',
};

function clampScore(value) {
  return Math.max(0, Math.min(100, Math.round(value)));
}

function statusScore(status) {
  if (status === 'Eligible') return 100;
  if (status === 'Not Eligible') return 18;
  return 58;
}

function evaluationRisk(evaluation) {
  const reviewPenalty = evaluation.status === 'Needs Review' ? 24 : 0;
  const rejectionPenalty = evaluation.status === 'Not Eligible' ? 48 : 0;
  return clampScore(100 - evaluation.confidence + reviewPenalty + rejectionPenalty);
}

export function calculateBidAnalytics(bid) {
  const evaluations = bid.evaluations || [];
  const averageConfidence =
    evaluations.reduce((total, evaluation) => total + evaluation.confidence, 0) / Math.max(evaluations.length, 1);
  const averageStatus =
    evaluations.reduce((total, evaluation) => total + statusScore(evaluation.status), 0) / Math.max(evaluations.length, 1);
  const averageRisk =
    evaluations.reduce((total, evaluation) => total + evaluationRisk(evaluation), 0) / Math.max(evaluations.length, 1);
  const flaggedCount = evaluations.filter((evaluation) => evaluation.status !== 'Eligible').length;

  return {
    complianceScore: clampScore((bid.score * 0.42) + (averageConfidence * 0.35) + (averageStatus * 0.23)),
    riskFactor: clampScore((averageRisk * 0.7) + (flaggedCount * 5) + ((100 - bid.priorityScore) * 0.08)),
    averageConfidence: clampScore(averageConfidence),
    flaggedCount,
  };
}

export function buildTenderAnalytics(bids) {
  const analytics = bids.map((bid) => calculateBidAnalytics(bid));
  const complianceScore =
    analytics.reduce((total, item) => total + item.complianceScore, 0) / Math.max(analytics.length, 1);
  const riskFactor = analytics.reduce((total, item) => total + item.riskFactor, 0) / Math.max(analytics.length, 1);
  const averageConfidence =
    analytics.reduce((total, item) => total + item.averageConfidence, 0) / Math.max(analytics.length, 1);
  const flaggedCount = analytics.reduce((total, item) => total + item.flaggedCount, 0);

  const categoryMap = new Map();
  bids.forEach((bid) => {
    bid.evaluations.forEach((evaluation) => {
      const current = categoryMap.get(evaluation.criterionId) || {
        category: CATEGORY_LABELS[evaluation.criterionId] || evaluation.criterionName,
        totalRisk: 0,
        totalConfidence: 0,
        count: 0,
      };
      current.totalRisk += evaluationRisk(evaluation);
      current.totalConfidence += evaluation.confidence;
      current.count += 1;
      categoryMap.set(evaluation.criterionId, current);
    });
  });

  return {
    complianceScore: clampScore(complianceScore),
    riskFactor: clampScore(riskFactor),
    averageConfidence: clampScore(averageConfidence),
    flaggedCount,
    bidCount: bids.length,
    radarData: Array.from(categoryMap.values()).map((item) => ({
      category: item.category,
      risk: clampScore(item.totalRisk / item.count),
      confidence: clampScore(item.totalConfidence / item.count),
    })),
  };
}
