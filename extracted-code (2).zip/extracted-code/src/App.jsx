import { useState } from 'react';
import { Navigate, NavLink, Route, Routes, useLocation } from 'react-router-dom';
import {
  BarChart2,
  CheckSquare,
  ChevronRight,
  FileInput,
  Files,
  HelpCircle,
  History,
  Hexagon,
  LayoutDashboard,
  ListOrdered,
  RefreshCcw,
  X,
} from 'lucide-react';
import { AnimatePresence, motion } from 'framer-motion';

import AuditTrail from './pages/AuditTrail';
import BidDetail from './pages/BidDetail';
import Bids from './pages/Bids';
import CriteriaReview from './pages/CriteriaReview';
import Dashboard from './pages/Dashboard';
import DocumentUpload from './pages/DocumentUpload';
import EvaluationReport from './pages/EvaluationReport';
import PriorityQueue from './pages/PriorityQueue';
import { useProcurement } from './context/ProcurementContext';

const navItems = [
  { type: 'section', label: 'Tender Ingestion' },
  { path: '/upload', label: 'Upload Document', icon: FileInput },
  { path: '/criteria', label: 'Review Criteria', icon: CheckSquare },
  { type: 'section', label: 'Evaluation Engine' },
  { path: '/bids', label: 'Bid Submissions', icon: Files },
  { path: '/evaluation', label: 'Intelligence Report', icon: BarChart2 },
  { path: '/priority', label: 'Priority Queue', icon: ListOrdered },
  { path: '/overview', label: 'Overview', icon: LayoutDashboard },
  { type: 'section', label: 'System Logs' },
  { path: '/audit', label: 'Audit Trail', icon: History },
];

const workflowSteps = [
  {
    label: 'Upload tender',
    detail: 'Bring in a tender PDF or the featured sample pack.',
    icon: FileInput,
    routes: ['/upload'],
  },
  {
    label: 'Review criteria',
    detail: 'Check extracted categories, rules, and documents.',
    icon: CheckSquare,
    routes: ['/criteria'],
  },
  {
    label: 'Evaluate bids',
    detail: 'Score compliance, compare submissions, and prioritize review.',
    icon: BarChart2,
    routes: ['/bids', '/evaluation', '/priority', '/overview', '/audit'],
  },
];

function getPageTitle(pathname) {
  if (pathname.startsWith('/bids/')) return 'Bid Detail';
  const item = navItems.find((navItem) => navItem.path === pathname);
  return item ? item.label : 'Tender Intelligence';
}

function getActiveWorkflowStep(pathname) {
  return workflowSteps.findIndex((step) => step.routes.some((route) => pathname.startsWith(route)));
}

function App() {
  const location = useLocation();
  const { resetDemo, selectedTender } = useProcurement();
  const [showHowItWorks, setShowHowItWorks] = useState(false);
  const activeWorkflowStep = getActiveWorkflowStep(location.pathname);

  return (
    <div className="app-container">
      <aside className="sidebar">
        <div className="brand-block">
          <div className="brand-mark ">
            <Hexagon size={22} color="white" />
          </div>
          <div>
            <h2 className="brand-title">
              TENDER<span>LENS</span>
            </h2>
            <p className="brand-subtitle">Tender Intelligence</p>
          </div>
        </div>

        <nav className="sidebar-nav">
          {navItems.map((item, index) => {
            if (item.type === 'section') {
              return (
                <div className="nav-section" key={`${item.label}-${index}`}>
                  {item.label}
                </div>
              );
            }
            const Icon = item.icon;
            return (
              <NavLink className="nav-link" key={item.path} to={item.path}>
                {({ isActive }) => (
                  <>
                    <Icon size={18} color={isActive ? 'var(--brand-accent)' : 'rgba(255,255,255,0.58)'} />
                    <span>{item.label}</span>
                  </>
                )}
              </NavLink>
            );
          })}
        </nav>

        <div className="sidebar-bottom">
          <button
            className={`how-it-works-trigger ${showHowItWorks ? 'active' : ''}`}
            onClick={() => setShowHowItWorks((current) => !current)}
            type="button"
          >
            <HelpCircle size={16} />
            <span>How it works?</span>
            <ChevronRight size={16} />
          </button>

          <div className="officer-card">
            <div className="avatar">PO</div>
            <div>
              <div className="officer-name">Cmdr. Sharma</div>
              <div className="officer-role">Procurement Officer</div>
            </div>
          </div>
        </div>
      </aside>

      <main className="main-content">
        <header className="header">
          <div>
            <h1 className="page-title">{getPageTitle(location.pathname)}</h1>
            <p className="page-kicker">{selectedTender?.gemId} / {selectedTender?.title}</p>
          </div>

          <div className="header-actions">
            <div className="engine-pill">
              <span className="live-dot" />
              Demo Engine Active
            </div>
            <button className="btn btn-outline btn-small" onClick={resetDemo}>
              <RefreshCcw size={16} /> Reset Demo
            </button>
          </div>
        </header>

        <div className="content-shell">
          <div className="page-container">
            <AnimatePresence mode="wait">
              <motion.div
                key={location.pathname + location.search}
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -12 }}
                transition={{ duration: 0.22, ease: 'easeOut' }}
              >
                <Routes>
                  <Route path="/" element={<Navigate replace to="/upload" />} />
                  <Route path="/overview" element={<Dashboard />} />
                  <Route path="/priority" element={<PriorityQueue />} />
                  <Route path="/upload" element={<DocumentUpload />} />
                  <Route path="/criteria" element={<CriteriaReview />} />
                  <Route path="/bids" element={<Bids />} />
                  <Route path="/bids/:bidId" element={<BidDetail />} />
                  <Route path="/evaluation" element={<EvaluationReport />} />
                  <Route path="/audit" element={<AuditTrail />} />
                </Routes>
              </motion.div>
            </AnimatePresence>
          </div>

          <AnimatePresence>
            {showHowItWorks && (
              <motion.aside
                animate={{ opacity: 1, x: 0 }}
                className="instruction-panel"
                exit={{ opacity: 0, x: 18 }}
                initial={{ opacity: 0, x: 18 }}
                transition={{ duration: 0.18, ease: 'easeOut' }}
              >
                <div className="instruction-panel-head">
                  <div>
                    <span className="eyebrow">How it works</span>
                    <h3>TenderLens workflow</h3>
                    <p>Use this quick guide while moving from tender ingestion to review priority.</p>
                  </div>
                  <button
                    aria-label="Close instructions"
                    className="icon-btn neutral"
                    onClick={() => setShowHowItWorks(false)}
                    type="button"
                  >
                    <X size={16} />
                  </button>
                </div>

                <div className="instruction-step-list">
                  {workflowSteps.map((step, index) => {
                    const StepIcon = step.icon;
                    const isActive = index === activeWorkflowStep;
                    return (
                      <article className={`instruction-step ${isActive ? 'active' : ''}`} key={step.label}>
                        <span className="instruction-step-number">{String(index + 1).padStart(2, '0')}</span>
                        <div className="instruction-step-copy">
                          <div className="instruction-step-label">
                            <StepIcon size={15} />
                            <strong>{step.label}</strong>
                          </div>
                          <p>{step.detail}</p>
                          {isActive && <span className="instruction-step-status">You are here</span>}
                        </div>
                      </article>
                    );
                  })}
                </div>

                <div className="instruction-panel-note">
                  <span className="mini-label">Recommended flow</span>
                  <p>
                    Start with the sample or a tender PDF, verify extracted criteria, run evaluation,
                    and then use Priority Queue to decide which bids need officer attention first.
                  </p>
                </div>
              </motion.aside>
            )}
          </AnimatePresence>
        </div>
      </main>
    </div>
  );
}

export default App;
